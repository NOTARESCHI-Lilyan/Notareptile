# 🦎 ReptileShop – Site de vente de reptiles (Laravel)

## Structure du projet

```
reptiles-laravel/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AccueilController.php
│   │   │   ├── ReptileController.php
│   │   │   ├── PanierController.php
│   │   │   ├── AuthController.php
│   │   │   ├── CommandeController.php
│   │   │   └── AdminController.php
│   │   └── Middleware/
│   │       └── AdminMiddleware.php
│   └── Models/
│       ├── User.php
│       ├── Categorie.php
│       ├── Reptile.php
│       ├── Commande.php
│       └── CommandeLigne.php
├── database/
│   ├── migrations/
│   │   ├── ..._create_users_table.php
│   │   ├── ..._create_categories_table.php
│   │   ├── ..._create_reptiles_table.php
│   │   └── ..._create_commandes_table.php
│   └── seeders/
│       └── DatabaseSeeder.php
├── resources/views/
│   ├── layouts/app.blade.php
│   ├── pages/
│   │   ├── accueil.blade.php
│   │   ├── apropos.blade.php
│   │   └── contact.blade.php
│   ├── reptiles/
│   │   ├── _carte.blade.php   ← partiel réutilisable
│   │   ├── index.blade.php    ← catalogue avec filtres
│   │   ├── categorie.blade.php
│   │   └── show.blade.php     ← fiche détaillée
│   ├── panier/
│   │   └── index.blade.php
│   ├── auth/
│   │   ├── login.blade.php
│   │   ├── register.blade.php
│   │   └── compte.blade.php
│   ├── commandes/
│   │   ├── index.blade.php
│   │   ├── show.blade.php
│   │   └── checkout.blade.php
│   └── admin/
│       ├── dashboard.blade.php
│       ├── commandes.blade.php
│       └── reptiles/
│           ├── index.blade.php
│           └── form.blade.php
├── routes/web.php
├── public/css/style.css
└── bootstrap/app.php
```

---

## ⚙️ Installation

### 1. Créer un nouveau projet Laravel

```bash
composer create-project laravel/laravel reptileshop
cd reptileshop
```

### 2. Copier les fichiers

Copie tous les dossiers/fichiers fournis dans le projet Laravel :
- `app/` → dans `app/`
- `database/` → dans `database/`
- `resources/views/` → dans `resources/views/`
- `routes/web.php` → remplace `routes/web.php`
- `public/css/style.css` → dans `public/css/`
- `bootstrap/app.php` → remplace `bootstrap/app.php`

### 3. Configurer la base de données

Dans `.env` :
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=reptileshop
DB_USERNAME=root
DB_PASSWORD=
```

### 4. Lancer les migrations + seeders

```bash
php artisan migrate --seed
```

### 5. Lien symbolique pour les images (uploads)

```bash
php artisan storage:link
```

### 6. Lancer le serveur

```bash
php artisan serve
```

Ouvre http://localhost:8000 dans ton navigateur.

---

## 🔑 Comptes de test

| Rôle  | Email                    | Mot de passe |
|-------|--------------------------|--------------|
| Admin | admin@reptileshop.fr     | password     |
| Client| jean@example.fr          | password     |

---

## 🗺️ Pages disponibles

| URL                          | Description                        |
|------------------------------|------------------------------------|
| `/`                          | Accueil avec vedettes & catégories |
| `/reptiles`                  | Catalogue avec filtres             |
| `/reptiles/categorie/{slug}` | Reptiles par catégorie             |
| `/reptiles/{id}`             | Fiche détaillée d'un reptile       |
| `/panier`                    | Panier (session)                   |
| `/commander`                 | Checkout (connecté requis)         |
| `/connexion`                 | Page de connexion                  |
| `/inscription`               | Page d'inscription                 |
| `/mon-compte`                | Espace client                      |
| `/mes-commandes`             | Historique commandes               |
| `/admin`                     | Dashboard admin                    |
| `/admin/reptiles`            | Gestion reptiles (CRUD)            |
| `/admin/commandes`           | Gestion commandes                  |
| `/a-propos`                  | Page à propos                      |
| `/contact`                   | Formulaire de contact              |

---

## 🚀 Fonctionnalités

- ✅ **Catalogue** avec filtres (catégorie, sexe, prix, recherche, tri)
- ✅ **Fiches produit** détaillées (morph, âge, sexe, conseils élevage)
- ✅ **Panier** en session (ajout, modification quantité, suppression)
- ✅ **Livraison gratuite** dès 150€
- ✅ **Authentification** complète (login, inscription, déconnexion)
- ✅ **Espace client** (compte, historique commandes)
- ✅ **Commandes** avec décrémentation du stock
- ✅ **Panel admin** (dashboard stats, CRUD reptiles, gestion commandes)
- ✅ **Design responsive** avec ton CSS exact
- ✅ **Navigation** avec sous-menus par catégorie
- ✅ **13 reptiles** de test en base (seeders)

---

## 📝 Prochaines étapes possibles

- Paiement en ligne (Stripe)
- Envoi d'emails (confirmation commande, contact)
- Galerie photos multiple par reptile
- Système de favoris
- Avis / notes clients
- Export PDF des commandes
