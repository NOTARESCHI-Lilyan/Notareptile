<?php

namespace App\Providers;

use App\Models\Espece;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        View::share('categories', Espece::withCount('reptiles')
            ->select('id', 'nom_commun', 'type_reptile', 'icone')
            ->get()
        );
    }
}
