<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TypeArticle extends Model
{
    protected $table    = 'type_articles';
    protected $fillable = ['libelle', 'icone'];

    public function articles()
    {
        return $this->hasMany(Article::class, 'type_article_id');
    }
}
