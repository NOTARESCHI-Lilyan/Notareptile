<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Commande extends Model
{
    protected $fillable = [
        'reference', 'est_valide', 'total', 'frais_livraison', 'statut',
        'adresse_livraison', 'ville_livraison', 'code_postal_livraison',
        'notes', 'utilisateur_id',
    ];

    protected $casts = [
        'est_valide'      => 'boolean',
        'total'           => 'decimal:2',
        'frais_livraison' => 'decimal:2',
    ];

    public function utilisateur()
    {
        return $this->belongsTo(Utilisateur::class, 'utilisateur_id');
    }

    public function lignes()
    {
        return $this->hasMany(LigneCommande::class, 'commande_id');
    }

    // ─── Accessors ─────────────────────────────────────────────────────

    public function getStatutLabelAttribute(): string
    {
        return match ($this->statut) {
            'en_attente' => 'En attente',
            'confirmee'  => 'Confirmée',
            'expediee'   => 'Expédiée',
            'livree'     => 'Livrée',
            'annulee'    => 'Annulée',
            default      => $this->statut,
        };
    }

    public function getStatutColorAttribute(): string
    {
        return match ($this->statut) {
            'en_attente' => '#c9a227',
            'confirmee'  => '#2d5016',
            'expediee'   => '#1a3a1a',
            'livree'     => '#6b8e23',
            'annulee'    => '#ff4757',
            default      => '#333',
        };
    }

    public function getSousTotalAttribute(): float
    {
        return (float) $this->total - (float) $this->frais_livraison;
    }

    public static function genererReference(): string
    {
        return 'REP-' . strtoupper(uniqid());
    }
}
