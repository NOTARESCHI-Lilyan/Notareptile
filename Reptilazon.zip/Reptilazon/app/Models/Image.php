<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    protected $fillable = ['chemin', 'principale', 'produit_id'];
    protected $casts    = ['principale' => 'boolean'];

    public function produit()
    {
        return $this->belongsTo(Produit::class, 'produit_id');
    }

    public function getUrlAttribute(): string
    {
        return asset('storage/' . $this->chemin);
    }
}
