<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Eleveur extends Model
{
    protected $fillable = ['nom', 'prenom', 'adresse', 'telephone'];

    public function getNomCompletAttribute(): string
    {
        return "{$this->prenom} {$this->nom}";
    }

    public function reptiles()
    {
        return $this->hasMany(Reptile::class, 'eleveur_id');
    }

    public function commentaires()
    {
        return $this->hasMany(Commentaire::class, 'eleveur_id');
    }
}
