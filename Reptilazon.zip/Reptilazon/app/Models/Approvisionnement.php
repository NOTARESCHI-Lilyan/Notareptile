<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Approvisionnement extends Model
{
    protected $fillable = ['article_id', 'fournisseur_id', 'quantite', 'date_appro'];
    protected $casts    = ['date_appro' => 'date'];

    public function article()
    {
        return $this->belongsTo(Article::class, 'article_id');
    }

    public function fournisseur()
    {
        return $this->belongsTo(Fournisseur::class, 'fournisseur_id');
    }
}
