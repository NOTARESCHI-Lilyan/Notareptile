<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Produit extends Model
{
    protected $fillable = ['prix_unitaire', 'stock', 'actif', 'en_vedette'];
    protected $casts    = [
        'prix_unitaire' => 'decimal:2',
        'actif'         => 'boolean',
        'en_vedette'    => 'boolean',
    ];

    // ─── Relations ─────────────────────────────────────────────────────

    /** Un produit peut être UN reptile OU UN article (1-1 exclusif) */
    public function reptile()
    {
        return $this->hasOne(Reptile::class, 'produit_id');
    }

    public function article()
    {
        return $this->hasOne(Article::class, 'produit_id');
    }

    public function images()
    {
        return $this->hasMany(Image::class, 'produit_id');
    }

    public function imagePrincipale()
    {
        return $this->hasOne(Image::class, 'produit_id')->where('principale', true);
    }

    public function lignesCommande()
    {
        return $this->hasMany(LigneCommande::class, 'produit_id');
    }

    // ─── Accessors ─────────────────────────────────────────────────────

    public function getImageUrlAttribute(): string
    {
        $img = $this->imagePrincipale ?? $this->images->first();
        if ($img) return asset('storage/' . $img->chemin);

        $nom = $this->reptile?->espece?->nom_commun ?? $this->article?->nom ?? 'Produit';
        return 'https://placehold.co/400x300/2d5016/ffffff?text=' . urlencode($nom);
    }

    public function getDisponibleAttribute(): bool
    {
        return $this->actif && $this->stock > 0;
    }

    // ─── Scopes ────────────────────────────────────────────────────────

    public function scopeActif($q)    { return $q->where('actif', true); }
    public function scopeVedette($q)  { return $q->where('en_vedette', true)->where('actif', true); }
    public function scopeDisponible($q){ return $q->where('actif', true)->where('stock', '>', 0); }
}
