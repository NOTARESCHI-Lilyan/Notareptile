<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Reptile extends Model
{
    protected $fillable = [
        'couleur', 'morph', 'age_mois', 'sexe',
        'espece_id', 'eleveur_id', 'produit_id',
    ];

    // ─── Relations ─────────────────────────────────────────────────────

    public function espece()
    {
        return $this->belongsTo(Espece::class, 'espece_id');
    }

    public function eleveur()
    {
        return $this->belongsTo(Eleveur::class, 'eleveur_id');
    }

    public function produit()
    {
        return $this->belongsTo(Produit::class, 'produit_id');
    }

    // ─── Raccourcis pratiques ───────────────────────────────────────────

    /** Prix via produit */
    public function getPrixAttribute(): float
    {
        return (float) $this->produit->prix_unitaire;
    }

    /** Stock via produit */
    public function getStockAttribute(): int
    {
        return $this->produit->stock;
    }

    /** Disponibilité via produit */
    public function getDisponibleAttribute(): bool
    {
        return $this->produit->disponible;
    }

    /** Image via produit */
    public function getImageUrlAttribute(): string
    {
        return $this->produit->image_url;
    }

    /** Âge formaté */
    public function getAgeFormatAttribute(): string
    {
        if (!$this->age_mois) return 'Inconnu';
        if ($this->age_mois < 12) return $this->age_mois . ' mois';
        $annees = floor($this->age_mois / 12);
        $mois   = $this->age_mois % 12;
        return $annees . ' an(s)' . ($mois ? ' ' . $mois . ' mois' : '');
    }

    // ─── Scopes ────────────────────────────────────────────────────────

    public function scopeDisponible($q)
    {
        return $q->whereHas('produit', fn($p) => $p->where('actif', true)->where('stock', '>', 0));
    }

    public function scopeVedette($q)
    {
        return $q->whereHas('produit', fn($p) => $p->where('en_vedette', true)->where('actif', true));
    }
}
