<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    protected $fillable = ['nom', 'description', 'type_article_id', 'produit_id'];

    public function typeArticle()
    {
        return $this->belongsTo(TypeArticle::class, 'type_article_id');
    }

    public function produit()
    {
        return $this->belongsTo(Produit::class, 'produit_id');
    }

    public function approvisionnements()
    {
        return $this->hasMany(Approvisionnement::class, 'article_id');
    }

    // Raccourcis
    public function getPrixAttribute(): float
    {
        return (float) $this->produit->prix_unitaire;
    }

    public function getImageUrlAttribute(): string
    {
        return $this->produit->image_url;
    }
}
