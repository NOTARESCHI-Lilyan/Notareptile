<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Espece extends Model
{
    protected $fillable = [
        'type_reptile', 'nom_commun', 'nom_scientifique',
        'lien_video', 'icone', 'description', 'conseils_elevage',
    ];

    public function reptiles()
    {
        return $this->hasMany(Reptile::class, 'espece_id');
    }
}
