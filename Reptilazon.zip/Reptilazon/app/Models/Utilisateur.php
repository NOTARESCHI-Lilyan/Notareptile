<?php
namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Utilisateur extends Authenticatable
{
    use Notifiable;

    protected $table = 'utilisateurs';

    protected $fillable = ['nom', 'prenom', 'email', 'telephone', 'adresse', 'password', 'is_admin'];
    protected $hidden   = ['password', 'remember_token'];
    protected $casts    = ['is_admin' => 'boolean'];

    public function getNomCompletAttribute(): string
    {
        return "{$this->prenom} {$this->nom}";
    }

    public function commandes()
    {
        return $this->hasMany(Commande::class, 'utilisateur_id');
    }

    public function commentaires()
    {
        return $this->hasMany(Commentaire::class, 'utilisateur_id');
    }
}
