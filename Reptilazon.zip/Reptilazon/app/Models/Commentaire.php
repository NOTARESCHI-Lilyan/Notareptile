<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Commentaire extends Model
{
    protected $fillable = ['titre', 'contenu', 'eleveur_id', 'utilisateur_id'];

    public function eleveur()
    {
        return $this->belongsTo(Eleveur::class, 'eleveur_id');
    }

    public function utilisateur()
    {
        return $this->belongsTo(Utilisateur::class, 'utilisateur_id');
    }
}
