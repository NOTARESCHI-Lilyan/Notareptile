<?php
namespace App\Http\Controllers;

use App\Models\Reptile;
use App\Models\Article;
use App\Models\Produit;
use App\Models\Espece;
use App\Models\Eleveur;
use App\Models\TypeArticle;
use App\Models\Commande;
use App\Models\Utilisateur;
use App\Models\Fournisseur;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class AdminController extends Controller
{
    // ─── Dashboard ─────────────────────────────────────────────────────

    public function dashboard()
    {
        $stats = [
            'reptiles'  => Reptile::count(),
            'articles'  => Article::count(),
            'commandes' => Commande::count(),
            'clients'   => Utilisateur::where('is_admin', false)->count(),
            'ca'        => Commande::whereIn('statut', ['confirmee','expediee','livree'])->sum('total'),
        ];
        $dernieresCommandes = Commande::with('utilisateur')->latest()->take(10)->get();
        return view('admin.dashboard', compact('stats', 'dernieresCommandes'));
    }

    // ─── CRUD Reptiles ─────────────────────────────────────────────────

    public function index()
    {
        $reptiles = Reptile::with(['espece', 'eleveur', 'produit'])->latest()->paginate(20);
        return view('admin.reptiles.index', compact('reptiles'));
    }

    public function create()
    {
        $especes  = Espece::all();
        $eleveurs = Eleveur::all();
        return view('admin.reptiles.form', compact('especes', 'eleveurs'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'espece_id'  => 'required|exists:especes,id',
            'eleveur_id' => 'required|exists:eleveurs,id',
            'couleur'    => 'nullable|string|max:100',
            'morph'      => 'nullable|string|max:100',
            'age_mois'   => 'nullable|integer|min:0',
            'sexe'       => 'nullable|in:mâle,femelle,inconnu',
            'prix'       => 'required|numeric|min:0',
            'stock'      => 'required|integer|min:0',
            'en_vedette' => 'boolean',
            'actif'      => 'boolean',
            'image'      => 'nullable|image|max:4096',
        ]);

        DB::transaction(function () use ($data, $request) {
            $produit = Produit::create([
                'prix_unitaire' => $data['prix'],
                'stock'         => $data['stock'],
                'en_vedette'    => $request->boolean('en_vedette'),
                'actif'         => $request->boolean('actif', true),
            ]);

            Reptile::create([
                'espece_id'  => $data['espece_id'],
                'eleveur_id' => $data['eleveur_id'],
                'couleur'    => $data['couleur'] ?? null,
                'morph'      => $data['morph'] ?? null,
                'age_mois'   => $data['age_mois'] ?? null,
                'sexe'       => $data['sexe'] ?? 'inconnu',
                'produit_id' => $produit->id,
            ]);

            if ($request->hasFile('image')) {
                $chemin = $request->file('image')->store('reptiles', 'public');
                $produit->images()->create(['chemin' => $chemin, 'principale' => true]);
            }
        });

        return redirect()->route('admin.reptiles.index')->with('success', 'Reptile ajouté !');
    }

    public function edit(int $id)
    {
        $reptile  = Reptile::with('produit.images', 'espece', 'eleveur')->findOrFail($id);
        $especes  = Espece::all();
        $eleveurs = Eleveur::all();
        return view('admin.reptiles.form', compact('reptile', 'especes', 'eleveurs'));
    }

    public function update(Request $request, int $id)
    {
        $reptile = Reptile::with('produit.images', 'espece', 'eleveur')->findOrFail($id);

        $data = $request->validate([
            'espece_id'  => 'required|exists:especes,id',
            'eleveur_id' => 'required|exists:eleveurs,id',
            'couleur'    => 'nullable|string|max:100',
            'morph'      => 'nullable|string|max:100',
            'age_mois'   => 'nullable|integer|min:0',
            'sexe'       => 'nullable|in:mâle,femelle,inconnu',
            'prix'       => 'required|numeric|min:0',
            'stock'      => 'required|integer|min:0',
            'en_vedette' => 'boolean',
            'actif'      => 'boolean',
            'image'      => 'nullable|image|max:4096',
        ]);

        DB::transaction(function () use ($data, $request, $reptile) {
            $reptile->produit->update([
                'prix_unitaire' => $data['prix'],
                'stock'         => $data['stock'],
                'en_vedette'    => $request->boolean('en_vedette'),
                'actif'         => $request->boolean('actif', true),
            ]);

            $reptile->update([
                'espece_id'  => $data['espece_id'],
                'eleveur_id' => $data['eleveur_id'],
                'couleur'    => $data['couleur'] ?? null,
                'morph'      => $data['morph'] ?? null,
                'age_mois'   => $data['age_mois'] ?? null,
                'sexe'       => $data['sexe'] ?? 'inconnu',
            ]);

            if ($request->hasFile('image')) {
                // Supprimer ancienne image principale
                $ancienne = $reptile->produit->images()->where('principale', true)->first();
                if ($ancienne) { Storage::disk('public')->delete($ancienne->chemin); $ancienne->delete(); }

                $chemin = $request->file('image')->store('reptiles', 'public');
                $reptile->produit->images()->create(['chemin' => $chemin, 'principale' => true]);
            }
        });

        return redirect()->route('admin.reptiles.index')->with('success', 'Reptile modifié !');
    }

    public function destroy(int $id)
    {
        $reptile = Reptile::with('produit.images')->findOrFail($id);
        foreach ($reptile->produit->images as $img) Storage::disk('public')->delete($img->chemin);
        $reptile->produit->delete(); // cascade supprime reptile + images
        return back()->with('success', 'Reptile supprimé.');
    }

    // ─── CRUD Articles (terrariums, nourriture, substrat) ──────────────

    public function articlesIndex()
    {
        $articles = Article::with(['typeArticle', 'produit'])->latest()->paginate(20);
        return view('admin.articles.index', compact('articles'));
    }

    public function articleCreate()
    {
        $types    = TypeArticle::all();
        $eleveurs = Eleveur::all();
        return view('admin.articles.form', compact('types'));
    }

    public function articleStore(Request $request)
    {
        $data = $request->validate([
            'nom'             => 'required|string|max:150',
            'description'     => 'nullable|string',
            'type_article_id' => 'required|exists:type_articles,id',
            'prix'            => 'required|numeric|min:0',
            'stock'           => 'required|integer|min:0',
            'en_vedette'      => 'boolean',
            'actif'           => 'boolean',
            'image'           => 'nullable|image|max:4096',
        ]);

        DB::transaction(function () use ($data, $request) {
            $produit = Produit::create([
                'prix_unitaire' => $data['prix'],
                'stock'         => $data['stock'],
                'en_vedette'    => $request->boolean('en_vedette'),
                'actif'         => $request->boolean('actif', true),
            ]);
            Article::create([
                'nom'             => $data['nom'],
                'description'     => $data['description'] ?? null,
                'type_article_id' => $data['type_article_id'],
                'produit_id'      => $produit->id,
            ]);
            if ($request->hasFile('image')) {
                $chemin = $request->file('image')->store('articles', 'public');
                $produit->images()->create(['chemin' => $chemin, 'principale' => true]);
            }
        });

        return redirect()->route('admin.articles.index')->with('success', 'Article ajouté !');
    }

    // ─── Commandes ─────────────────────────────────────────────────────

    public function commandes()
    {
        $commandes = Commande::with('utilisateur')->latest()->paginate(20);
        return view('admin.commandes', compact('commandes'));
    }

    public function updateStatut(Request $request, int $id)
    {
        $validated = $request->validate([
            'statut' => 'required|in:en_attente,confirmee,expediee,livree,annulee',
        ]);
        Commande::findOrFail($id)->update($validated);
        return back()->with('success', 'Statut mis à jour.');
    }
}
