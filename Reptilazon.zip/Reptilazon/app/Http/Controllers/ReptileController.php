<?php
namespace App\Http\Controllers;

use App\Models\Reptile;
use App\Models\Espece;
use Illuminate\Http\Request;

class ReptileController extends Controller
{
    public function index(Request $request)
    {
        $query   = Reptile::disponible()->with(['espece', 'produit.images', 'eleveur']);
        $especes = Espece::all();

        if ($request->filled('type'))     $query->whereHas('espece', fn($q) => $q->where('type_reptile', $request->type));
        if ($request->filled('sexe'))     $query->where('sexe', $request->sexe);
        if ($request->filled('prix_max')) $query->whereHas('produit', fn($q) => $q->where('prix_unitaire', '<=', $request->prix_max));
        if ($request->filled('recherche'))$query->whereHas('espece', fn($q) => $q->where('nom_commun', 'like', '%' . $request->recherche . '%'));

        match ($request->get('tri', 'recent')) {
            'prix_asc'  => $query->join('produits', 'reptiles.produit_id', '=', 'produits.id')->orderBy('produits.prix_unitaire', 'asc')->select('reptiles.*'),
            'prix_desc' => $query->join('produits', 'reptiles.produit_id', '=', 'produits.id')->orderBy('produits.prix_unitaire', 'desc')->select('reptiles.*'),
            'nom'       => $query->join('especes', 'reptiles.espece_id', '=', 'especes.id')->orderBy('especes.nom_commun')->select('reptiles.*'),
            default     => $query->latest(),
        };

        $reptiles = $query->paginate(12)->withQueryString();
        return view('reptiles.index', compact('reptiles', 'especes'));
    }

    public function parType(string $type)
    {
        $categorie = Espece::where('type_reptile', $type)->firstOrFail();

        $reptiles = Reptile::disponible()
            ->whereHas('espece', fn($q) => $q->where('type_reptile', $type))
            ->with(['espece', 'produit.images'])
            ->paginate(12);

        return view('reptiles.par_type', compact('reptiles', 'categorie'));
    }

    public function show(int $id)
    {
        $reptile    = Reptile::with(['espece', 'eleveur', 'produit.images'])->findOrFail($id);
        $similaires = Reptile::disponible()
            ->whereHas('espece', fn($q) => $q->where('type_reptile', $reptile->espece->type_reptile))
            ->where('id', '!=', $reptile->id)
            ->with(['espece', 'produit'])
            ->take(4)->get();

        return view('reptiles.show', compact('reptile', 'similaires'));
    }
}
