<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\TypeArticle;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    /**
     * Liste tous les articles d'une catégorie : nourriture, substrat, terrarium
     */
    public function index(Request $request, string $categorie)
    {
        $categoriesAutorisees = ['nourriture', 'substrat', 'terrarium'];

        if (!in_array($categorie, $categoriesAutorisees)) {
            abort(404);
        }

        $typeArticle = TypeArticle::where('libelle', $categorie)->firstOrFail();

        $query = Article::with(['produit.images', 'typeArticle'])
            ->where('type_article_id', $typeArticle->id)
            ->whereHas('produit', fn($q) => $q->where('actif', true));

        // Filtre prix
        if ($request->filled('prix_max')) {
            $query->whereHas('produit', fn($q) => $q->where('prix_unitaire', '<=', $request->prix_max));
        }

        // Filtre recherche
        if ($request->filled('recherche')) {
            $query->where('nom', 'like', '%' . $request->recherche . '%');
        }

        // Tri
        match ($request->get('tri', 'recent')) {
            'prix_asc'  => $query->join('produits', 'articles.produit_id', '=', 'produits.id')->orderBy('produits.prix_unitaire', 'asc')->select('articles.*'),
            'prix_desc' => $query->join('produits', 'articles.produit_id', '=', 'produits.id')->orderBy('produits.prix_unitaire', 'desc')->select('articles.*'),
            'nom'       => $query->orderBy('nom', 'asc'),
            default     => $query->latest(),
        };

        $articles = $query->paginate(12)->withQueryString();

        return view('articles.index', compact('articles', 'typeArticle', 'categorie'));
    }

    /**
     * Détail d'un article
     */
    public function show(int $id)
    {
        $article = Article::with(['produit.images', 'typeArticle'])->findOrFail($id);

        // Articles similaires (même type)
        $similaires = Article::with(['produit.images'])
            ->where('type_article_id', $article->type_article_id)
            ->where('id', '!=', $article->id)
            ->whereHas('produit', fn($q) => $q->where('actif', true))
            ->take(4)
            ->get();

        return view('articles.show', compact('article', 'similaires'));
    }
}
