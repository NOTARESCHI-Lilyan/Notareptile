<?php
namespace App\Http\Controllers;

use App\Models\Produit;
use Illuminate\Http\Request;

class PanierController extends Controller
{
    // Session panier : ['produit_id' => ['quantite' => 1, 'nom' => ..., 'prix' => ...]]

    public function index()
    {
        $panier = session('panier', []);
        $total  = array_sum(array_map(fn($i) => $i['prix'] * $i['quantite'], $panier));
        return view('panier.index', compact('panier', 'total'));
    }

    public function ajouter(Request $request, int $produitId)
    {
        $produit = Produit::disponible()->with(['reptile.espece', 'article'])->findOrFail($produitId);
        $panier  = session('panier', []);
        $qte     = max(1, (int) $request->input('quantite', 1));

        // Nom selon le type de produit
        $nom = $produit->reptile
            ? $produit->reptile->espece->nom_commun . ($produit->reptile->morph ? ' ' . $produit->reptile->morph : '')
            : $produit->article->nom;

        $type = $produit->reptile ? '🦎 Reptile' : '📦 ' . $produit->article->typeArticle->libelle;

        if (isset($panier[$produitId])) {
            $panier[$produitId]['quantite'] = min($panier[$produitId]['quantite'] + $qte, $produit->stock);
        } else {
            $panier[$produitId] = [
                'produit_id' => $produitId,
                'nom'        => $nom,
                'type'       => $type,
                'image'      => $produit->image_url,
                'prix'       => (float) $produit->prix_unitaire,
                'quantite'   => min($qte, $produit->stock),
            ];
        }

        session(['panier' => $panier]);
        return back()->with('success', "« {$nom} » ajouté au panier !");
    }

    public function modifier(Request $request, int $produitId)
    {
        $panier = session('panier', []);
        $qte    = (int) $request->input('quantite', 1);

        if (isset($panier[$produitId])) {
            $produit = Produit::findOrFail($produitId);
            $panier[$produitId]['quantite'] = min(max(1, $qte), $produit->stock);
            session(['panier' => $panier]);
        }

        return back()->with('success', 'Quantité mise à jour.');
    }

    public function supprimer(int $produitId)
    {
        $panier = session('panier', []);
        $nom    = $panier[$produitId]['nom'] ?? 'Article';
        unset($panier[$produitId]);
        session(['panier' => $panier]);
        return back()->with('success', "« {$nom} » retiré du panier.");
    }

    public function vider()
    {
        session()->forget('panier');
        return back()->with('success', 'Panier vidé.');
    }
}
