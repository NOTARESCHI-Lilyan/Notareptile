<?php
namespace App\Http\Controllers;

use App\Models\Utilisateur;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function loginForm()
    {
        return Auth::check() ? redirect()->route('compte') : view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email'    => 'required|email',
            'password' => 'required',
        ]);

        if (Auth::attempt($credentials, $request->boolean('remember'))) {
            $request->session()->regenerate();
            return redirect()->intended(route('accueil'))->with('success', 'Bienvenue !');
        }

        return back()->withErrors(['email' => 'Email ou mot de passe incorrect.'])->onlyInput('email');
    }

    public function registerForm()
    {
        return Auth::check() ? redirect()->route('compte') : view('auth.register');
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'nom'                  => 'required|string|max:100',
            'prenom'               => 'required|string|max:100',
            'email'                => 'required|email|unique:utilisateurs',
            'telephone'            => 'nullable|string|max:20',
            'password'             => 'required|min:8|confirmed',
        ]);

        $data['password'] = Hash::make($data['password']);
        $user = Utilisateur::create($data);
        Auth::login($user);

        return redirect()->route('accueil')->with('success', 'Bienvenue ' . $user->prenom . ' !');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('accueil');
    }

    public function compte()
    {
        $user      = Auth::user();
        $commandes = $user->commandes()->latest()->take(5)->get();
        return view('auth.compte', compact('user', 'commandes'));
    }
}
