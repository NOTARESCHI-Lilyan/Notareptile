<?php

namespace App\Http\Controllers;

use App\Models\Espece;
use App\Models\Reptile;

class AccueilController extends Controller
{
    public function index()
    {
        $categories = Espece::withCount('reptiles')->select('id', 'nom_commun', 'type_reptile', 'icone')->get();
        $reptilesVedette = Reptile::with('espece', 'produit')
                            ->whereHas('produit', fn($q) => $q->where('en_vedette', true))
                            ->take(4)->get();
        $derniers       = Reptile::with('espece', 'produit')
                            ->latest()->take(4)->get();

        return view('pages.accueil', compact('categories', 'reptilesVedette', 'derniers'));
    }

    public function apropos()
    {
        return view('pages.apropos');
    }

    public function contact()
    {
        return view('pages.contact');
    }

    public function contactEnvoyer()
    {
        return redirect()->route('contact')->with('success', 'Message envoyé !');
    }
}
