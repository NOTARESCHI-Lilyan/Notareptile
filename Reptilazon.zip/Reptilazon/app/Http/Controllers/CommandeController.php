<?php
namespace App\Http\Controllers;

use App\Models\Commande;
use App\Models\Produit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CommandeController extends Controller
{
    public function index()
    {
        $commandes = Auth::user()->commandes()->with('lignes.produit')->latest()->get();
        return view('commandes.index', compact('commandes'));
    }

    public function show(int $id)
    {
        $commande = Commande::where('utilisateur_id', Auth::id())
            ->with('lignes.produit.reptile.espece', 'lignes.produit.article')
            ->findOrFail($id);
        return view('commandes.show', compact('commande'));
    }

    public function checkout()
    {
        $panier = session('panier', []);
        if (empty($panier)) return redirect()->route('panier.index')->with('error', 'Votre panier est vide.');

        $sousTotal = array_sum(array_map(fn($i) => $i['prix'] * $i['quantite'], $panier));
        $frais     = $sousTotal >= 150 ? 0 : 9.90;
        $total     = $sousTotal + $frais;
        $user      = Auth::user();

        return view('commandes.checkout', compact('panier', 'sousTotal', 'frais', 'total', 'user'));
    }

    public function confirmer(Request $request)
    {
        $data = $request->validate([
            'adresse'     => 'required|string|max:255',
            'ville'       => 'required|string|max:100',
            'code_postal' => 'required|string|max:10',
            'notes'       => 'nullable|string|max:500',
        ]);

        $panier = session('panier', []);
        if (empty($panier)) return redirect()->route('panier.index');

        DB::transaction(function () use ($panier, $data) {
            $sousTotal = array_sum(array_map(fn($i) => $i['prix'] * $i['quantite'], $panier));
            $frais     = $sousTotal >= 150 ? 0 : 9.90;

            $commande = Commande::create([
                'utilisateur_id'        => Auth::id(),
                'reference'             => Commande::genererReference(),
                'total'                 => $sousTotal + $frais,
                'frais_livraison'       => $frais,
                'statut'                => 'en_attente',
                'adresse_livraison'     => $data['adresse'],
                'ville_livraison'       => $data['ville'],
                'code_postal_livraison' => $data['code_postal'],
                'notes'                 => $data['notes'] ?? null,
            ]);

            foreach ($panier as $produitId => $item) {
                $commande->lignes()->create([
                    'produit_id'   => $produitId,
                    'quantite'     => $item['quantite'],
                    'prix_unitaire'=> $item['prix'],
                ]);
                Produit::where('id', $produitId)->decrement('stock', $item['quantite']);
            }

            session()->forget('panier');
        });

        return redirect()->route('commandes.index')->with('success', 'Commande passée avec succès !');
    }
}
