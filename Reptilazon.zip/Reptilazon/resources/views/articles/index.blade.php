@extends('layouts.app')
@section('titre', ucfirst($typeArticle->libelle) . ' – ReptileShop')

@section('contenu')

{{-- Hero catégorie --}}
<div style="background:linear-gradient(135deg,var(--vert-principal),var(--vert-secondaire));padding:50px 20px;text-align:center;margin-bottom:40px;">
    <div style="max-width:800px;margin:0 auto;">
        <p style="font-size:3.5em;margin:0;">{{ $typeArticle->icone ?? ($categorie === 'nourriture' ? '🍖' : ($categorie === 'substrat' ? '🪨' : '🏠')) }}</p>
        <h1 style="color:#fff;margin:10px 0 5px;font-size:2.2em;">{{ ucfirst($typeArticle->libelle) }}</h1>
        <p style="color:rgba(255,255,255,0.85);font-size:1.1em;margin:0;">
            @if($categorie === 'nourriture') Alimentation vivante, congelée et en boîte pour vos reptiles
            @elseif($categorie === 'substrat') Substrats naturels adaptés à chaque espèce
            @else Terrariums, équipements et accessoires d'élevage
            @endif
        </p>
    </div>
</div>

<div style="max-width:1200px;margin:0 auto;padding:0 20px;">

    {{-- Navigation catégories --}}
    <div style="display:flex;gap:12px;justify-content:center;margin-bottom:35px;flex-wrap:wrap;">
        <a href="{{ route('articles.index', 'nourriture') }}"
           style="padding:10px 22px;border-radius:25px;text-decoration:none;font-weight:600;font-size:0.95em;
                  background:{{ $categorie === 'nourriture' ? 'var(--vert-secondaire)' : 'var(--beige)' }};
                  color:{{ $categorie === 'nourriture' ? '#fff' : 'var(--brun)' }};">
            🍖 Nourriture
        </a>
        <a href="{{ route('articles.index', 'substrat') }}"
           style="padding:10px 22px;border-radius:25px;text-decoration:none;font-weight:600;font-size:0.95em;
                  background:{{ $categorie === 'substrat' ? 'var(--vert-secondaire)' : 'var(--beige)' }};
                  color:{{ $categorie === 'substrat' ? '#fff' : 'var(--brun)' }};">
            🪨 Substrat
        </a>
        <a href="{{ route('articles.index', 'terrarium') }}"
           style="padding:10px 22px;border-radius:25px;text-decoration:none;font-weight:600;font-size:0.95em;
                  background:{{ $categorie === 'terrarium' ? 'var(--vert-secondaire)' : 'var(--beige)' }};
                  color:{{ $categorie === 'terrarium' ? '#fff' : 'var(--brun)' }};">
            🏠 Terrarium & Équipements
        </a>
    </div>

    {{-- Filtres --}}
    <div style="background:var(--beige);border-radius:15px;padding:25px;margin-bottom:35px;">
        <form method="GET" action="{{ route('articles.index', $categorie) }}" style="display:flex;gap:15px;flex-wrap:wrap;align-items:flex-end;">
            <div style="flex:1;min-width:200px;">
                <label style="display:block;font-weight:600;color:var(--brun);margin-bottom:6px;">🔍 Recherche</label>
                <input type="text" name="recherche" value="{{ request('recherche') }}"
                    placeholder="Nom du produit..."
                    style="width:100%;padding:10px 14px;border:2px solid #ddd;border-radius:8px;font-size:0.95em;box-sizing:border-box;">
            </div>
            <div style="min-width:150px;">
                <label style="display:block;font-weight:600;color:var(--brun);margin-bottom:6px;">💶 Prix max (€)</label>
                <input type="number" name="prix_max" value="{{ request('prix_max') }}"
                    placeholder="Ex: 50"
                    style="width:100%;padding:10px 14px;border:2px solid #ddd;border-radius:8px;font-size:0.95em;box-sizing:border-box;">
            </div>
            <div style="min-width:160px;">
                <label style="display:block;font-weight:600;color:var(--brun);margin-bottom:6px;">🔃 Trier par</label>
                <select name="tri" style="width:100%;padding:10px 14px;border:2px solid #ddd;border-radius:8px;font-size:0.95em;background:#fff;">
                    <option value="recent"    {{ request('tri','recent') === 'recent'    ? 'selected' : '' }}>Plus récent</option>
                    <option value="prix_asc"  {{ request('tri') === 'prix_asc'           ? 'selected' : '' }}>Prix croissant</option>
                    <option value="prix_desc" {{ request('tri') === 'prix_desc'          ? 'selected' : '' }}>Prix décroissant</option>
                    <option value="nom"       {{ request('tri') === 'nom'               ? 'selected' : '' }}>Nom A→Z</option>
                </select>
            </div>
            <div style="display:flex;gap:10px;">
                <button type="submit" class="ajoutPanier" style="width:auto;padding:11px 24px;">Filtrer</button>
                @if(request()->hasAny(['recherche','prix_max','tri']))
                    <a href="{{ route('articles.index', $categorie) }}" style="padding:11px 18px;background:#fff;border:2px solid var(--beige);border-radius:8px;color:var(--brun);text-decoration:none;font-weight:600;">✕</a>
                @endif
            </div>
        </form>
    </div>

    {{-- Résultats --}}
    <p style="color:var(--brun);margin-bottom:20px;font-weight:500;">
        {{ $articles->total() }} produit(s) trouvé(s)
    </p>

    @if($articles->count())
        <div class="grille_produit">
            @foreach($articles as $article)
                @include('articles._carte', ['article' => $article])
            @endforeach
        </div>

        <div style="text-align:center;margin:40px 0;">
            {{ $articles->links() }}
        </div>
    @else
        <div class="container" style="text-align:center;padding:60px 20px;">
            <p style="font-size:3em;">😔</p>
            <p style="color:var(--brun);font-size:1.1em;">Aucun produit trouvé dans cette catégorie.</p>
            <a href="{{ route('articles.index', $categorie) }}" style="color:var(--vert-secondaire);font-weight:600;">Réinitialiser les filtres</a>
        </div>
    @endif
</div>

@endsection
