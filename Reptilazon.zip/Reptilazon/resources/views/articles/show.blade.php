@extends('layouts.app')
@section('titre', $article->nom . ' – ReptileShop')

@section('contenu')

<div style="max-width:1200px;margin:30px auto;padding:0 20px;">
    <a href="{{ route('articles.index', $article->typeArticle->libelle) }}" class="button-retour">
        ← Retour {{ ucfirst($article->typeArticle->libelle) }}
    </a>
</div>

<div class="container" style="display:grid;grid-template-columns:1fr 1fr;gap:40px;text-align:left;margin-top:10px;">

    {{-- Image --}}
    <div>
        <img src="{{ $article->produit->image_url }}" alt="{{ $article->nom }}"
            style="width:100%;border-radius:15px;object-fit:cover;max-height:450px;box-shadow:0 10px 30px rgba(0,0,0,0.2);">

        {{-- Galerie si plusieurs images --}}
        @if($article->produit->images->count() > 1)
            <div style="display:flex;gap:10px;margin-top:15px;flex-wrap:wrap;">
                @foreach($article->produit->images as $img)
                    <img src="{{ asset('storage/' . $img->chemin) }}" alt="{{ $article->nom }}"
                        style="width:80px;height:60px;object-fit:cover;border-radius:8px;cursor:pointer;
                               border:2px solid var(--beige);transition:border-color .2s;"
                        onmouseover="document.querySelector('.img-principale').src=this.src"
                        class="img-miniature">
                @endforeach
            </div>
        @endif
    </div>

    {{-- Infos --}}
    <div style="display:flex;flex-direction:column;gap:15px;">

        <p class="categ_produit" style="text-align:left;">
            {{ $article->typeArticle->icone ?? '' }} {{ ucfirst($article->typeArticle->libelle) }}
        </p>

        <h2 style="text-align:left;margin:0;padding:0;">{{ $article->nom }}</h2>

        <p class="prix_produit" style="text-align:left;font-size:2.5em;margin:0;">
            {{ number_format($article->produit->prix_unitaire, 2, ',', ' ') }} €
        </p>

        {{-- Stock --}}
        <div>
            @if($article->produit->disponible)
                <span style="background:var(--vert-secondaire);color:#fff;padding:8px 18px;border-radius:20px;font-weight:600;display:inline-block;">
                    ✅ En stock – {{ $article->produit->stock }} disponible(s)
                </span>
            @else
                <span style="background:#ff4757;color:#fff;padding:8px 18px;border-radius:20px;font-weight:600;display:inline-block;">
                    ❌ Indisponible
                </span>
            @endif
        </div>

        {{-- Description --}}
        @if($article->description)
            <p style="text-align:left;font-size:1.05em;line-height:1.7;color:var(--gris-fonce);">
                {{ $article->description }}
            </p>
        @endif

        {{-- Infos spécifiques terrarium --}}
        @if($article->typeArticle->libelle === 'terrarium')
            <div style="background:var(--beige);border-radius:12px;padding:20px;border-left:4px solid var(--accent);">
                <h4 style="margin:0 0 10px;color:var(--brun);">🏠 Équipements inclus / compatibles</h4>
                <ul style="margin:0;padding-left:20px;color:var(--gris-fonce);line-height:1.9;">
                    @if($article->lampe_chauffante ?? false)
                        <li>🔆 Lampe chauffante</li>
                    @endif
                    @if($article->uv ?? false)
                        <li>☀️ Lampe UV</li>
                    @endif
                    @if($article->thermostat ?? false)
                        <li>🌡️ Thermostat</li>
                    @endif
                    @if($article->ventilation ?? false)
                        <li>💨 Système de ventilation</li>
                    @endif
                    @if(!($article->lampe_chauffante ?? false) && !($article->uv ?? false) && !($article->thermostat ?? false))
                        <li>Voir la description pour les équipements compatibles</li>
                    @endif
                </ul>
            </div>
        @endif

        {{-- Ajout panier --}}
        @if($article->produit->disponible)
            <form method="POST" action="{{ route('panier.ajouter', $article->produit_id) }}" style="display:flex;gap:15px;align-items:center;">
                @csrf
                <div style="display:flex;align-items:center;gap:10px;">
                    <label style="color:var(--brun);font-weight:600;">Quantité :</label>
                    <input type="number" name="quantite" value="1" min="1" max="{{ $article->produit->stock }}"
                        style="width:80px;padding:10px;border:2px solid var(--beige);border-radius:8px;text-align:center;font-size:1em;">
                </div>
                <button type="submit" class="ajoutPanier" style="width:auto;padding:12px 30px;">
                    🛒 Ajouter au panier
                </button>
            </form>
        @else
            <button class="ajoutPanier" disabled style="opacity:0.5;cursor:not-allowed;">Indisponible</button>
        @endif

    </div>
</div>

{{-- Produits similaires --}}
@if($similaires->count())
    <div style="max-width:1200px;margin:50px auto 20px;padding:0 20px;">
        <h2 style="text-align:center;">🔗 Produits similaires</h2>
        <div class="grille_produit">
            @foreach($similaires as $sim)
                @include('articles._carte', ['article' => $sim])
            @endforeach
        </div>
    </div>
@endif

@endsection
