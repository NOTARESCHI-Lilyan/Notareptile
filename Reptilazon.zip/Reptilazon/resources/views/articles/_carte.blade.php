<div class="carte_produit">
    @if($article->produit->en_vedette)
        <span class="badge_produit">⭐ Vedette</span>
    @elseif($article->created_at->diffInDays() < 7)
        <span class="badge_produit">🆕 Nouveau</span>
    @endif

    <div class="image_produit">
        <img src="{{ $article->produit->image_url }}"
             alt="{{ $article->nom }}"
             style="width:100%;height:100%;object-fit:cover;">
    </div>

    <div class="info_produit">
        <p class="categ_produit">
            {{ $article->typeArticle->icone ?? '' }} {{ ucfirst($article->typeArticle->libelle) }}
        </p>
        <h3 class="nom_produit">{{ $article->nom }}</h3>

        @if($article->description)
            <p style="color:var(--gris-fonce);font-size:0.88em;margin:5px 0;line-height:1.5;
                       overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;">
                {{ $article->description }}
            </p>
        @endif

        <p class="prix_produit">{{ number_format($article->produit->prix_unitaire, 2, ',', ' ') }} €</p>

        @if($article->produit->disponible)
            <p style="color:var(--vert-secondaire);font-size:0.85em;font-weight:600;margin:4px 0;">
                ✅ En stock ({{ $article->produit->stock }})
            </p>
        @else
            <p style="color:#ff4757;font-size:0.85em;font-weight:600;margin:4px 0;">❌ Indisponible</p>
        @endif

        <a href="{{ route('articles.show', $article->id) }}" style="text-decoration:none;">
            <button class="ajoutPanier" style="background:linear-gradient(135deg,var(--vert-secondaire),var(--vert-principal));margin-bottom:8px;">
                🔍 Voir le produit
            </button>
        </a>

        @if($article->produit->disponible)
            <form method="POST" action="{{ route('panier.ajouter', $article->produit_id) }}">
                @csrf
                <button type="submit" class="ajoutPanier">🛒 Ajouter au panier</button>
            </form>
        @endif
    </div>
</div>
