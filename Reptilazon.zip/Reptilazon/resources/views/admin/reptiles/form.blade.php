@extends('layouts.app')
@section('titre', isset($reptile) ? 'Modifier ' . $reptile->espece->nom_commun : 'Ajouter un reptile')

@section('contenu')

<h2>{{ isset($reptile) ? '✏️ Modifier ' . $reptile->espece->nom_commun : '➕ Ajouter un reptile' }}</h2>

<div style="max-width:800px;margin:0 auto;padding:0 20px;">
    <a href="{{ route('admin.reptiles.index') }}" class="button-retour" style="position:relative;top:0;left:0;display:inline-block;margin-bottom:20px;">← Retour</a>

    <form method="POST"
          action="{{ isset($reptile) ? route('admin.reptiles.update', $reptile->id) : route('admin.reptiles.store') }}"
          enctype="multipart/form-data"
          style="display:flex;flex-direction:column;gap:20px;background:#fff;padding:35px;border-radius:15px;box-shadow:0 10px 30px rgba(0,0,0,0.1);">
        @csrf
        @if(isset($reptile)) @method('PUT') @endif

        @if($errors->any())
            <div style="background:#ffe0e0;padding:15px;border-radius:8px;color:#c00;">
                @foreach($errors->all() as $error)
                    <p style="margin:4px 0;">⚠️ {{ $error }}</p>
                @endforeach
            </div>
        @endif

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">

            {{-- Espèce --}}
            <div style="display:flex;flex-direction:column;gap:6px;">
                <label style="color:var(--brun);font-weight:600;">Espèce *</label>
                <select name="espece_id" required style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
                    <option value="">-- Choisir une espèce --</option>
                    @foreach($especes as $espece)
                        <option value="{{ $espece->id }}"
                            {{ old('espece_id', $reptile->espece_id ?? '') == $espece->id ? 'selected' : '' }}>
                            {{ $espece->icone }} {{ $espece->nom_commun }} ({{ $espece->type_reptile }})
                        </option>
                    @endforeach
                </select>
            </div>

            {{-- Éleveur --}}
            <div style="display:flex;flex-direction:column;gap:6px;">
                <label style="color:var(--brun);font-weight:600;">Éleveur *</label>
                <select name="eleveur_id" required style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
                    <option value="">-- Choisir un éleveur --</option>
                    @foreach($eleveurs as $eleveur)
                        <option value="{{ $eleveur->id }}"
                            {{ old('eleveur_id', $reptile->eleveur_id ?? '') == $eleveur->id ? 'selected' : '' }}>
                            {{ $eleveur->nom_complet }} — {{ $eleveur->adresse }}
                        </option>
                    @endforeach
                </select>
            </div>

            {{-- Couleur --}}
            <div style="display:flex;flex-direction:column;gap:6px;">
                <label style="color:var(--brun);font-weight:600;">Couleur</label>
                <input type="text" name="couleur" value="{{ old('couleur', $reptile->couleur ?? '') }}"
                    placeholder="Ex: Normal, Albino..."
                    style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
            </div>

            {{-- Morph --}}
            <div style="display:flex;flex-direction:column;gap:6px;">
                <label style="color:var(--brun);font-weight:600;">Morph</label>
                <input type="text" name="morph" value="{{ old('morph', $reptile->morph ?? '') }}"
                    placeholder="Ex: Pastel, Clown..."
                    style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
            </div>

            {{-- Prix --}}
            <div style="display:flex;flex-direction:column;gap:6px;">
                <label style="color:var(--brun);font-weight:600;">Prix (€) *</label>
                <input type="number" name="prix" value="{{ old('prix', $reptile->produit->prix_unitaire ?? '') }}"
                    step="0.01" min="0" required
                    style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
            </div>

            {{-- Stock --}}
            <div style="display:flex;flex-direction:column;gap:6px;">
                <label style="color:var(--brun);font-weight:600;">Stock *</label>
                <input type="number" name="stock" value="{{ old('stock', $reptile->produit->stock ?? 1) }}"
                    min="0" required
                    style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
            </div>

            {{-- Sexe --}}
            <div style="display:flex;flex-direction:column;gap:6px;">
                <label style="color:var(--brun);font-weight:600;">Sexe</label>
                <select name="sexe" style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
                    <option value="inconnu" {{ old('sexe', $reptile->sexe ?? 'inconnu') === 'inconnu' ? 'selected' : '' }}>⚥ Inconnu</option>
                    <option value="mâle"    {{ old('sexe', $reptile->sexe ?? '')         === 'mâle'    ? 'selected' : '' }}>♂ Mâle</option>
                    <option value="femelle" {{ old('sexe', $reptile->sexe ?? '')         === 'femelle' ? 'selected' : '' }}>♀ Femelle</option>
                </select>
            </div>

            {{-- Âge --}}
            <div style="display:flex;flex-direction:column;gap:6px;">
                <label style="color:var(--brun);font-weight:600;">Âge (mois)</label>
                <input type="number" name="age_mois" value="{{ old('age_mois', $reptile->age_mois ?? '') }}"
                    min="0" placeholder="Ex: 6"
                    style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
            </div>

        </div>

        {{-- Image --}}
        <div style="display:flex;flex-direction:column;gap:6px;">
            <label style="color:var(--brun);font-weight:600;">Image</label>
            @if(isset($reptile) && $reptile->produit->images->count())
                <img src="{{ asset('storage/' . $reptile->produit->images->first()->chemin) }}"
                     alt="" style="width:150px;border-radius:8px;margin-bottom:8px;">
            @endif
            <input type="file" name="image" accept="image/*"
                style="padding:10px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
        </div>

        {{-- Options --}}
        <div style="display:flex;gap:20px;">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="checkbox" name="en_vedette" value="1"
                    {{ old('en_vedette', $reptile->produit->en_vedette ?? false) ? 'checked' : '' }}>
                <span style="color:var(--brun);font-weight:600;">⭐ Mettre en vedette</span>
            </label>
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="checkbox" name="actif" value="1"
                    {{ old('actif', $reptile->produit->actif ?? true) ? 'checked' : '' }}>
                <span style="color:var(--brun);font-weight:600;">✅ Actif (visible)</span>
            </label>
        </div>

        <button type="submit" class="panier-commande" style="border-radius:25px;">
            {{ isset($reptile) ? '💾 Enregistrer les modifications' : '➕ Ajouter le reptile' }}
        </button>
    </form>
</div>

@endsection
