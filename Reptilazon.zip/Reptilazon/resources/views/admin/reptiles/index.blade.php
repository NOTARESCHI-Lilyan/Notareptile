@extends('layouts.app')
@section('titre', 'Admin – Reptiles')
@section('contenu')
<h2>🦎 Gestion des Reptiles</h2>
<div style="max-width:1200px;margin:0 auto;padding:0 20px;">
    <div style="text-align:right;margin-bottom:20px;">
        <a href="{{ route('admin.reptiles.create') }}">
            <button class="ajoutPanier" style="width:auto;padding:12px 25px;">➕ Ajouter un reptile</button>
        </a>
    </div>
    <div class="container" style="padding:20px;">
        <table style="width:100%;border-collapse:collapse;">
            <thead>
                <tr style="border-bottom:2px solid var(--beige);">
                    <th style="padding:10px;text-align:left;color:var(--brun);">Nom</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Type / Espèce</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Éleveur</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Prix</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Stock</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Statut</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($reptiles as $reptile)
                    <tr style="border-bottom:1px solid var(--beige);">
                        <td style="padding:10px;">
                            <strong>{{ $reptile->espece->nom_commun }}</strong>
                            @if($reptile->morph)
                                <span style="color:#888;font-size:0.9em;"> – {{ $reptile->morph }}</span>
                            @endif
                            @if($reptile->produit->en_vedette)
                                <span style="color:var(--accent);">⭐</span>
                            @endif
                            <br>
                            <small style="color:#888;">{{ ucfirst($reptile->sexe) }} • {{ $reptile->age_format }}</small>
                        </td>
                        <td style="padding:10px;">
                            <span>{{ $reptile->espece->type_reptile }}</span><br>
                            <small style="color:#888;font-style:italic;">{{ $reptile->espece->nom_scientifique }}</small>
                        </td>
                        <td style="padding:10px;">{{ $reptile->eleveur->nom_complet }}</td>
                        <td style="padding:10px;color:var(--accent-orange);font-weight:700;">
                            {{ number_format($reptile->produit->prix_unitaire, 2, ',', ' ') }} €
                        </td>
                        <td style="padding:10px;">
                            <span style="color:{{ $reptile->produit->stock > 0 ? 'var(--vert-secondaire)' : '#ff4757' }};font-weight:600;">
                                {{ $reptile->produit->stock }}
                            </span>
                        </td>
                        <td style="padding:10px;">
                            <span style="background:{{ $reptile->produit->actif ? 'var(--vert-secondaire)' : '#999' }};color:#fff;padding:4px 10px;border-radius:15px;font-size:0.85em;">
                                {{ $reptile->produit->actif ? 'Actif' : 'Inactif' }}
                            </span>
                        </td>
                        <td style="padding:10px;display:flex;gap:8px;">
                            <a href="{{ route('admin.reptiles.edit', $reptile->id) }}">
                                <button class="button-retour" style="position:relative;top:0;left:0;padding:7px 15px;font-size:0.85em;">✏️ Modifier</button>
                            </a>
                            <form method="POST" action="{{ route('admin.reptiles.destroy', $reptile->id) }}">
                                @csrf @method('DELETE')
                                <button type="submit" class="delete-btn" style="width:auto;padding:7px 15px;border-radius:8px;"
                                    onclick="return confirm('Supprimer {{ $reptile->espece->nom_commun }} ?')">🗑</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <div style="margin-top:20px;">{{ $reptiles->links() }}</div>
    </div>
</div>
@endsection
