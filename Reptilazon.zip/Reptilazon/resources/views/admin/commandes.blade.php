@extends('layouts.app')
@section('titre', 'Gestion commandes – Admin')

@section('contenu')

<button class="backButton" onclick="window.location.href='{{ route('admin.dashboard') }}'">← Dashboard</button>

<h2>📦 Gestion des Commandes</h2>

<div style="max-width:1100px;margin:0 auto;padding:0 20px;">

    @if(session('success'))
        <div style="background:#d4edda;border:1px solid #c3e6cb;padding:12px 20px;border-radius:8px;margin-bottom:20px;color:#155724;">
            ✅ {{ session('success') }}
        </div>
    @endif

    @forelse($commandes as $commande)
        <div class="container" style="margin-bottom:15px;text-align:left;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:15px;">

                {{-- Infos commande --}}
                <div>
                    <h3 style="text-align:left;margin:0;">{{ $commande->reference }}</h3>
                    <p style="margin:4px 0;color:var(--brun);font-size:0.9em;">
                        📅 {{ $commande->created_at->format('d/m/Y à H:i') }}
                    </p>
                    <p style="margin:0;font-size:0.9em;">
                        👤 <strong>{{ $commande->user->nom_complet ?? 'Client supprimé' }}</strong>
                        ({{ $commande->user->email ?? '' }})
                    </p>
                    <p style="margin:4px 0;font-size:0.9em;">
                        🏠 {{ $commande->adresse_livraison }},
                           {{ $commande->code_postal_livraison }} {{ $commande->ville_livraison }}
                    </p>
                </div>

                {{-- Total --}}
                <div style="text-align:center;">
                    <p class="prix_produit" style="margin:0;font-size:1.4em;">
                        {{ number_format($commande->total, 2, ',', ' ') }} €
                    </p>
                    <p style="margin:4px 0;color:var(--brun);font-size:0.85em;">
                        dont {{ $commande->frais_livraison == 0 ? 'livraison offerte' : number_format($commande->frais_livraison, 2, ',', ' ') . ' € livraison' }}
                    </p>
                    <p style="margin:0;font-size:0.85em;">
                        {{ $commande->lignes->count() }} article(s)
                    </p>
                </div>

                {{-- Changement de statut --}}
                <div>
                    <form method="POST" action="{{ route('admin.commandes.statut', $commande->id) }}"
                          style="display:flex;flex-direction:column;gap:8px;align-items:flex-end;">
                        @csrf
                        @method('PATCH')
                        <select name="statut"
                                style="padding:8px 14px;border:2px solid var(--beige);border-radius:8px;font-size:0.95em;background:white;">
                            @foreach(['en_attente' => 'En attente', 'confirmee' => 'Confirmée', 'expediee' => 'Expédiée', 'livree' => 'Livrée', 'annulee' => 'Annulée'] as $val => $label)
                                <option value="{{ $val }}" {{ $commande->statut === $val ? 'selected' : '' }}>
                                    {{ $label }}
                                </option>
                            @endforeach
                        </select>
                        <button type="submit" class="connexion"
                                style="padding:8px 20px;font-size:0.9em;">
                            Mettre à jour
                        </button>
                    </form>
                </div>

            </div>

            {{-- Articles résumés --}}
            <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:8px;">
                @foreach($commande->lignes as $ligne)
                    <span style="background:var(--beige);padding:4px 12px;border-radius:15px;font-size:0.82em;">
                        🦎 {{ $ligne->reptile->nom ?? 'Supprimé' }} ×{{ $ligne->quantite }}
                    </span>
                @endforeach
            </div>

        </div>
    @empty
        <div class="container">
            <p>Aucune commande pour le moment.</p>
        </div>
    @endforelse

    {{-- Pagination --}}
    <div style="margin-top:20px;text-align:center;">
        {{ $commandes->links() }}
    </div>

</div>

@endsection
