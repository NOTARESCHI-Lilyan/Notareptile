@extends('layouts.app')
@section('titre', 'Admin – Dashboard')

@section('contenu')

<h2>⚙️ Tableau de bord Admin</h2>

{{-- Stats --}}
<div style="max-width:1200px;margin:0 auto;padding:0 20px;">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:40px;">
        @foreach([
            ['🦎', 'Reptiles', $stats['reptiles'], 'var(--vert-secondaire)'],
            ['📦', 'Commandes', $stats['commandes'], 'var(--accent-orange)'],
            ['👥', 'Clients', $stats['clients'], 'var(--brun)'],
            ['💰', 'Chiffre d\'affaires', number_format($stats['ca'], 2, ',', ' ') . ' €', 'var(--accent)'],
        ] as [$icon, $label, $val, $color])
            <div class="container" style="padding:25px;margin:0;">
                <div style="font-size:2.5em;">{{ $icon }}</div>
                <div style="font-size:2em;font-weight:900;color:{{ $color }};">{{ $val }}</div>
                <div style="color:var(--brun);font-weight:600;">{{ $label }}</div>
            </div>
        @endforeach
    </div>

    {{-- Actions --}}
    <div style="display:flex;gap:15px;flex-wrap:wrap;margin-bottom:30px;justify-content:center;">
        <a href="{{ route('admin.reptiles.index') }}">
            <button class="connexion">🦎 Gérer les reptiles</button>
        </a>
        <a href="{{ route('admin.reptiles.create') }}">
            <button class="ajoutPanier" style="width:auto;padding:15px 30px;">➕ Ajouter un reptile</button>
        </a>
        <a href="{{ route('admin.commandes') }}">
            <button class="buttonRetour" style="position:relative;top:0;left:0;">📦 Gérer les commandes</button>
        </a>
    </div>

    {{-- Dernières commandes --}}
    <div class="container">
        <h3>Dernières commandes</h3>
        <table style="width:100%;border-collapse:collapse;">
            <thead>
                <tr style="border-bottom:2px solid var(--beige);">
                    <th style="padding:10px;text-align:left;color:var(--brun);">Référence</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Client</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Total</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Statut</th>
                    <th style="padding:10px;text-align:left;color:var(--brun);">Date</th>
                </tr>
            </thead>
            <tbody>
                @foreach($dernieresCommandes as $cmd)
                    <tr style="border-bottom:1px solid var(--beige);">
                        <td style="padding:10px;font-weight:600;">{{ $cmd->reference }}</td>
                        <td style="padding:10px;">{{ $cmd->user->nom_complet }}</td>
                        <td style="padding:10px;color:var(--accent-orange);font-weight:700;">{{ number_format($cmd->total, 2, ',', ' ') }} €</td>
                        <td style="padding:10px;">
                            <span style="background:{{ $cmd->statut_color }};color:#fff;padding:4px 12px;border-radius:15px;font-size:0.85em;">{{ $cmd->statut_label }}</span>
                        </td>
                        <td style="padding:10px;color:var(--brun);font-size:0.9em;">{{ $cmd->created_at->format('d/m/Y') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

@endsection
