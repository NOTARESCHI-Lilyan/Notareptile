@extends('layouts.app')
@section('titre', 'Mon Compte – ReptileShop')

@section('contenu')

<h2>👤 Mon Compte</h2>

<div style="max-width:900px;margin:0 auto;padding:0 20px;">
    <div class="container" style="text-align:left;">
        <h3 style="text-align:left;">Bonjour, {{ $user->nom_complet }} 👋</h3>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;margin-top:20px;">
            <div><strong>Email :</strong> {{ $user->email }}</div>
            <div><strong>Téléphone :</strong> {{ $user->telephone ?? 'Non renseigné' }}</div>
            <div><strong>Adresse :</strong> {{ $user->adresse ?? 'Non renseignée' }}</div>
            <div><strong>Ville :</strong> {{ $user->ville ?? 'Non renseignée' }} {{ $user->code_postal }}</div>
        </div>
    </div>

    <h2>📦 Mes dernières commandes</h2>

    @if($commandes->count())
        @foreach($commandes as $commande)
            <div class="container" style="margin-bottom:15px;text-align:left;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
                    <div>
                        <strong>{{ $commande->reference }}</strong><br>
                        <span style="color:var(--brun);font-size:0.9em;">{{ $commande->created_at->format('d/m/Y') }}</span>
                    </div>
                    <span style="background:{{ $commande->statut_color }};color:#fff;padding:6px 15px;border-radius:20px;font-weight:600;font-size:0.9em;">
                        {{ $commande->statut_label }}
                    </span>
                    <strong style="color:var(--accent-orange);font-size:1.3em;">{{ number_format($commande->total, 2, ',', ' ') }} €</strong>
                    <a href="{{ route('commandes.show', $commande->id) }}">
                        <button class="button-retour" style="position:relative;top:0;left:0;">Voir le détail</button>
                    </a>
                </div>
            </div>
        @endforeach
        <div style="text-align:center;margin-top:20px;">
            <a href="{{ route('commandes.index') }}">
                <button class="connexion">Voir toutes mes commandes</button>
            </a>
        </div>
    @else
        <div class="container">
            <p>Vous n'avez pas encore passé de commande.</p>
            <a href="{{ route('reptiles.index') }}"><button class="connexion">Découvrir le catalogue</button></a>
        </div>
    @endif
</div>

@endsection
