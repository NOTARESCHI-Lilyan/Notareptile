@extends('layouts.app')
@section('titre', 'Connexion – ReptileShop')

@section('contenu')

<h2>🔐 Connexion</h2>

<form method="POST" action="{{ route('login.post') }}" class="connectionForm">
    @csrf
    <label for="email">Email</label>
    <input type="email" name="email" id="email" value="{{ old('email') }}" required placeholder="votre@email.fr">

    <label for="password">Mot de passe</label>
    <input type="password" name="password" id="password" required placeholder="••••••••">

    <label style="flex-direction:row;gap:10px;display:flex;align-items:center;font-size:0.95em;">
        <input type="checkbox" name="remember"> Se souvenir de moi
    </label>

    <input type="submit" value="Se connecter" style="padding:14px;border-radius:25px;cursor:pointer;font-size:1.05em;">
</form>

<p style="text-align:center;">Pas encore de compte ? <a href="{{ route('register') }}" style="color:var(--vert-secondaire);font-weight:700;">Créer un compte</a></p>

@endsection
