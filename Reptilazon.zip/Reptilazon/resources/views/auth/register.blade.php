@extends('layouts.app')
@section('titre', 'Inscription – ReptileShop')

@section('contenu')

<h2>📝 Créer un compte</h2>

<form method="POST" action="{{ route('register.post') }}" class="inscriptionForm">
    @csrf

    <input type="text" name="prenom" value="{{ old('prenom') }}" required placeholder="Prénom"
        style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
    <input type="text" name="nom" value="{{ old('nom') }}" required placeholder="Nom"
        style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
    <input type="email" name="email" value="{{ old('email') }}" required placeholder="Email"
        style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
    <input type="tel" name="telephone" value="{{ old('telephone') }}" placeholder="Téléphone (optionnel)"
        style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
    <input type="password" name="password" required placeholder="Mot de passe (8 caractères min.)"
        style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
    <input type="password" name="password_confirmation" required placeholder="Confirmer le mot de passe"
        style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">

    <button type="submit" class="connexion" style="width:100%;padding:14px;font-size:1.05em;">Créer mon compte</button>
</form>

<p style="text-align:center;">Déjà un compte ? <a href="{{ route('login') }}" style="color:var(--vert-secondaire);font-weight:700;">Se connecter</a></p>

@endsection
