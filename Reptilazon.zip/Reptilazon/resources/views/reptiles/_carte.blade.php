<div class="carte_produit">
    @if($reptile->produit->en_vedette)
        <span class="badge_produit">⭐ Vedette</span>
    @elseif($reptile->created_at->diffInDays() < 7)
        <span class="badge_produit">🆕 Nouveau</span>
    @endif

    <div class="image_produit">
        <img src="{{ $reptile->produit->images->first()->url ?? 'https://placehold.co/300x200?text=Reptile' }}" 
             alt="{{ $reptile->espece->nom_commun }}" 
             style="width:100%;height:100%;object-fit:cover;">
    </div>

    <div class="info_produit">
        <p class="categ_produit">{{ $reptile->espece->type_reptile }}</p>
        <h3 class="nom_produit">{{ $reptile->espece->nom_commun }}</h3>
        @if($reptile->espece->nom_scientifique)
            <p style="font-style:italic;color:var(--brun);font-size:0.85em;margin:5px 0;">
                {{ $reptile->espece->nom_scientifique }}
            </p>
        @endif
        <div class="note_produit">
            @if($reptile->sexe) 
                {{ $reptile->sexe === 'mâle' ? '♂' : ($reptile->sexe === 'femelle' ? '♀' : '⚥') }} 
                {{ ucfirst($reptile->sexe) }} &nbsp;|&nbsp; 
            @endif
            @if($reptile->age_mois) 🗓 {{ $reptile->age_mois }} mois @endif
        </div>
        @if($reptile->morph)
            <p style="color:var(--accent);font-size:0.85em;font-weight:700;">Morph : {{ $reptile->morph }}</p>
        @endif
        <p class="prix_produit">{{ number_format($reptile->produit->prix_unitaire, 2, ',', ' ') }} €</p>

        <a href="{{ route('reptiles.show', $reptile->id) }}" style="text-decoration:none;">
            <button class="ajoutPanier" style="background:linear-gradient(135deg,var(--vert-secondaire),var(--vert-principal));margin-bottom:8px;">
                🔍 Voir la fiche
            </button>
        </a>

        <form method="POST" action="{{ route('panier.ajouter', $reptile->id) }}">
            @csrf
            <button type="submit" class="ajoutPanier">🛒 Ajouter au panier</button>
        </form>
    </div>
</div>
