@extends('layouts.app')
@section('titre', $categorie->nom . ' – ReptileShop')

@section('contenu')

<div style="max-width:1200px;margin:30px auto;padding:0 20px;position:relative;">
    <a href="{{ route('reptiles.index') }}" class="button-retour">← Catalogue</a>
</div>

<h2>{{ $categorie->icone }} {{ $categorie->nom }}</h2>
@if($categorie->description)
    <p>{{ $categorie->description }}</p>
@endif

<p style="text-align:center;color:var(--brun);">{{ $reptiles->total() }} reptile(s) disponible(s)</p>

@if($reptiles->count())
    <div class="grille_produit">
        @foreach($reptiles as $reptile)
            @include('reptiles._carte', ['reptile' => $reptile])
        @endforeach
    </div>
    <div style="text-align:center;margin:40px 0;">
        {{ $reptiles->links() }}
    </div>
@else
    <div class="container">
        <p>😔 Aucun reptile disponible dans cette catégorie pour le moment.</p>
    </div>
@endif

@endsection
