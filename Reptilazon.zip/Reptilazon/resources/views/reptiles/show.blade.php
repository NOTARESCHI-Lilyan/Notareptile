@extends('layouts.app')
@section('titre', $reptile->espece->nom_commun . ' – ReptileShop')

@section('contenu')

<div style="max-width:1200px;margin:30px auto;padding:0 20px;position:relative;">
    <a href="{{ url()->previous() }}" class="button-retour">← Retour</a>
</div>

<div class="container" style="display:grid;grid-template-columns:1fr 1fr;gap:40px;text-align:left;margin-top:10px;">
    {{-- Image --}}
    <div>
        <img src="{{ $reptile->image_url }}" alt="{{ $reptile->espece->nom_commun }}"
            style="width:100%;border-radius:15px;object-fit:cover;max-height:450px;box-shadow:0 10px 30px rgba(0,0,0,0.2);">
    </div>

    {{-- Infos --}}
    <div style="display:flex;flex-direction:column;gap:15px;">
        <p class="categ_produit" style="text-align:left;">{{ $reptile->espece->nom_commun }}</p>
        <h2 style="text-align:left;margin:0;padding:0;">{{ $reptile->espece->nom_commun }}</h2>
        @if($reptile->espece->nom_scientifique ?? null)
            <p style="font-style:italic;color:var(--brun);margin:0;font-size:1.1em;">{{ $reptile->espece->nom_scientifique }}</p>
        @endif

        <p class="prix_produit" style="text-align:left;font-size:2.5em;margin:0;">{{ number_format($reptile->prix, 2, ',', ' ') }} €</p>

        {{-- Badges infos --}}
        <div style="display:flex;flex-wrap:wrap;gap:10px;">
            @if($reptile->sexe)
                <span style="background:var(--beige);padding:8px 15px;border-radius:20px;font-weight:600;color:var(--brun);">
                    {{ $reptile->sexe === 'mâle' ? '♂' : ($reptile->sexe === 'femelle' ? '♀' : '⚥') }} {{ ucfirst($reptile->sexe) }}
                </span>
            @endif
            @if($reptile->age_mois)
                <span style="background:var(--beige);padding:8px 15px;border-radius:20px;font-weight:600;color:var(--brun);">
                    🗓 {{ $reptile->age_format }}
                </span>
            @endif
            @if($reptile->morph)
                <span style="background:linear-gradient(135deg,var(--accent),#d4af37);color:#fff;padding:8px 15px;border-radius:20px;font-weight:600;">
                    💎 {{ $reptile->morph }}
                </span>
            @endif
            <span style="background:{{ $reptile->disponible ? 'var(--vert-secondaire)' : '#ff4757' }};color:#fff;padding:8px 15px;border-radius:20px;font-weight:600;">
                {{ $reptile->disponible ? '✅ En stock (' . $reptile->stock . ')' : '❌ Indisponible' }}
            </span>
        </div>

        <p style="text-align:left;font-size:1.05em;line-height:1.7;color:var(--gris-fonce);">{{ $reptile->description ?? '' }}</p>

        @if($reptile->disponible)
            <form method="POST" action="{{ route('panier.ajouter', $reptile->id) }}" style="display:flex;gap:15px;align-items:center;">
                @csrf
                <div style="display:flex;align-items:center;gap:10px;">
                    <label style="color:var(--brun);font-weight:600;">Quantité :</label>
                    <input type="number" name="quantite" value="1" min="1" max="{{ $reptile->stock }}"
                        style="width:80px;padding:10px;border:2px solid var(--beige);border-radius:8px;text-align:center;font-size:1em;">
                </div>
                <button type="submit" class="ajoutPanier" style="width:auto;padding:12px 30px;">🛒 Ajouter au panier</button>
            </form>
        @else
            <button class="ajoutPanier" disabled style="opacity:0.5;cursor:not-allowed;">Indisponible</button>
        @endif
    </div>
</div>

@if($reptile->conseils_elevage ?? null)
<div class="container" style="margin-top:20px;text-align:left;">
    <h2 style="text-align:center;">📋 Conseils d'élevage</h2>
    <div style="background:var(--beige);padding:25px;border-radius:12px;border-left:5px solid var(--vert-secondaire);">
        <p style="text-align:left;white-space:pre-line;margin:0;">{{ $reptile->conseils_elevage }}</p>
    </div>
</div>
@endif

{{-- Reptiles similaires --}}
@if($similaires->count())
<h2>🔗 Reptiles similaires</h2>
<div class="grille_produit">
    @foreach($similaires as $sim)
        @include('reptiles._carte', ['reptile' => $sim])
    @endforeach
</div>
@endif

@endsection
