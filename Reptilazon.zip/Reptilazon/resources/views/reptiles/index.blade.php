@extends('layouts.app')
@section('titre', 'Catalogue – ReptileShop')

@section('contenu')

<h2>🦎 Catalogue</h2>

{{-- Filtres --}}
<div class="container" style="margin-bottom:20px;">
    <form method="GET" action="{{ route('reptiles.index') }}" style="display:flex;flex-wrap:wrap;gap:15px;align-items:flex-end;justify-content:center;">
        <div>
            <label style="display:block;color:var(--brun);font-weight:600;margin-bottom:5px;">Recherche</label>
            <input type="text" name="recherche" value="{{ request('recherche') }}"
                placeholder="Nom du reptile..."
                style="padding:10px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;width:200px;">
        </div>
        <div>
            <label style="display:block;color:var(--brun);font-weight:600;margin-bottom:5px;">Catégorie</label>
            <select name="type" style="padding:10px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
                <option value="">Toutes</option>
                @foreach($especes as $espece)
                    <option value="{{ $espece->type_reptile }}" {{ request('type') == $espece->type_reptile ? 'selected' : '' }}>
                        {{ $espece->icone ?? '🦎' }} {{ $espece->nom_commun }}
                    </option>
                @endforeach
            </select>
        </div>
        <div>
            <label style="display:block;color:var(--brun);font-weight:600;margin-bottom:5px;">Sexe</label>
            <select name="sexe" style="padding:10px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
                <option value="">Tous</option>
                <option value="mâle" {{ request('sexe') === 'mâle' ? 'selected' : '' }}>♂ Mâle</option>
                <option value="femelle" {{ request('sexe') === 'femelle' ? 'selected' : '' }}>♀ Femelle</option>
            </select>
        </div>
        <div>
            <label style="display:block;color:var(--brun);font-weight:600;margin-bottom:5px;">Prix max (€)</label>
            <input type="number" name="prix_max" value="{{ request('prix_max') }}" min="0" step="10"
                style="padding:10px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;width:120px;">
        </div>
        <div>
            <label style="display:block;color:var(--brun);font-weight:600;margin-bottom:5px;">Trier par</label>
            <select name="tri" style="padding:10px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
                <option value="recent" {{ request('tri') === 'recent' ? 'selected' : '' }}>Plus récent</option>
                <option value="prix_asc" {{ request('tri') === 'prix_asc' ? 'selected' : '' }}>Prix croissant</option>
                <option value="prix_desc" {{ request('tri') === 'prix_desc' ? 'selected' : '' }}>Prix décroissant</option>
                <option value="nom" {{ request('tri') === 'nom' ? 'selected' : '' }}>Nom A-Z</option>
            </select>
        </div>
        <button type="submit" class="ajoutPanier" style="width:auto;padding:12px 25px;">🔍 Filtrer</button>
        <a href="{{ route('reptiles.index') }}">
            <button type="button" class="buttonRetour" style="position:relative;top:0;left:0;">✖ Réinitialiser</button>
        </a>
    </form>
</div>

{{-- Résultats --}}
<p style="text-align:center;color:var(--brun);">{{ $reptiles->total() }} reptile(s) trouvé(s)</p>

@if($reptiles->count())
    <div class="grille_produit">
        @foreach($reptiles as $reptile)
            @include('reptiles._carte', ['reptile' => $reptile])
        @endforeach
    </div>

    <div style="text-align:center;margin:40px 0;">
        {{ $reptiles->links() }}
    </div>
@else
    <div class="container">
        <p style="font-size:1.3em;">😔 Aucun reptile ne correspond à vos critères.</p>
        <a href="{{ route('reptiles.index') }}">
            <button class="connexion">Voir tout le catalogue</button>
        </a>
    </div>
@endif

@endsection
