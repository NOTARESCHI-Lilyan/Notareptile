@extends('layouts.app')
@section('titre', 'Commander – Notareptile')

@section('contenu')

<h2>✅ Finaliser ma commande</h2>

<div style="max-width:900px;margin:0 auto;padding:0 20px;display:grid;grid-template-columns:1fr 1fr;gap:30px;">

    {{-- Formulaire livraison --}}
    <div class="container">
        <h3>📦 Adresse de livraison</h3>

        @if($errors->any())
            <div style="background:#fff3cd;border:1px solid #ffc107;padding:12px;border-radius:8px;margin-bottom:15px;">
                <ul style="margin:0;padding-left:20px;">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('commander.confirmer') }}"
              style="display:flex;flex-direction:column;gap:15px;text-align:left;">
            @csrf

            <label style="color:var(--brun);font-weight:600;">Adresse</label>
            <input type="text" name="adresse"
                   value="{{ old('adresse', $user->adresse) }}"
                   required placeholder="12 rue des Reptiles"
                   style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">

            <label style="color:var(--brun);font-weight:600;">Ville</label>
            <input type="text" name="ville"
                   value="{{ old('ville', $user->ville) }}"
                   required placeholder="Paris"
                   style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">

            <label style="color:var(--brun);font-weight:600;">Code postal</label>
            <input type="text" name="code_postal"
                   value="{{ old('code_postal', $user->code_postal) }}"
                   required placeholder="75000"
                   style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">

            <label style="color:var(--brun);font-weight:600;">Notes (optionnel)</label>
            <textarea name="notes"
                      placeholder="Instructions de livraison..."
                      style="padding:12px;border:2px solid var(--beige);border-radius:8px;font-size:1em;resize:vertical;min-height:80px;">{{ old('notes') }}</textarea>

            <button type="submit" class="panier-commande" style="border-radius:25px;margin-top:10px;">
                🦎 Confirmer la commande
            </button>
        </form>
    </div>

    {{-- Récapitulatif --}}
    <div class="container">
        <h3>🛒 Récapitulatif</h3>

        @foreach($panier as $reptileId => $item)
            <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--beige);">
                <div>
                    <strong>{{ $item['nom'] }}</strong><br>
                    <span style="color:var(--brun);font-size:0.9em;">
                        {{ $item['categorie'] }} · x{{ $item['quantite'] }}
                    </span>
                </div>
                <strong style="color:var(--accent-orange);">
                    {{ number_format($item['prix'] * $item['quantite'], 2, ',', ' ') }} €
                </strong>
            </div>
        @endforeach

        <div style="margin-top:15px;display:flex;flex-direction:column;gap:8px;">
            <div style="display:flex;justify-content:space-between;">
                <span>Sous-total</span>
                <strong>{{ number_format($sousTotal, 2, ',', ' ') }} €</strong>
            </div>
            <div style="display:flex;justify-content:space-between;">
                <span>Livraison</span>
                <strong>{{ $frais == 0 ? 'Gratuite 🎉' : number_format($frais, 2, ',', ' ') . ' €' }}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:1.3em;font-weight:900;
                        color:var(--accent-orange);border-top:2px solid var(--accent-orange);
                        padding-top:10px;margin-top:5px;">
                <span>Total TTC</span>
                <span>{{ number_format($total, 2, ',', ' ') }} €</span>
            </div>
        </div>

        @if($frais == 0)
            <p style="text-align:center;color:var(--vert-principal);font-size:0.85em;margin-top:10px;">
                🎉 Livraison offerte à partir de 150 €
            </p>
        @else
            <p style="text-align:center;color:var(--brun);font-size:0.85em;margin-top:10px;">
                Livraison gratuite à partir de 150 € d'achat
                ({{ number_format(150 - $sousTotal, 2, ',', ' ') }} € restant)
            </p>
        @endif
    </div>

</div>

@endsection
