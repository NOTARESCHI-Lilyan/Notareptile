@extends('layouts.app')
@section('titre', 'Mes Commandes – Notareptile')

@section('contenu')

<h2>📦 Mes Commandes</h2>

<div style="max-width:1000px;margin:0 auto;padding:0 20px;">

    @forelse($commandes as $commande)
        <div class="container" style="margin-bottom:20px;text-align:left;">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:15px;">

                {{-- Référence & date --}}
                <div>
                    <h3 style="text-align:left;margin:0;">{{ $commande->reference }}</h3>
                    <p style="margin:5px 0;color:var(--brun);">
                        {{ $commande->created_at->format('d/m/Y à H:i') }}
                    </p>
                    <p style="margin:0;">
                        {{ $commande->lignes->count() }} article(s) ·
                        Livraison : {{ $commande->adresse_livraison }}, {{ $commande->ville_livraison }}
                    </p>
                </div>

                {{-- Badge statut --}}
                <span style="background:{{ $commande->statut_color }};color:#fff;
                             padding:8px 20px;border-radius:25px;font-weight:700;white-space:nowrap;">
                    {{ $commande->statut_label }}
                </span>

                {{-- Total & bouton --}}
                <div style="text-align:right;">
                    <p class="prix_produit" style="margin:0;">
                        {{ number_format($commande->total, 2, ',', ' ') }} €
                    </p>
                    <a href="{{ route('commandes.show', $commande->id) }}">
                        <button class="button-retour"
                                style="position:relative;top:0;left:0;margin-top:10px;">
                            Voir détail
                        </button>
                    </a>
                </div>

            </div>

            {{-- Miniatures des reptiles commandés --}}
            @if($commande->lignes->isNotEmpty())
                <div style="margin-top:15px;display:flex;flex-wrap:wrap;gap:10px;">
                    @foreach($commande->lignes as $ligne)
                        <div style="display:flex;align-items:center;gap:8px;
                                    background:var(--beige);padding:6px 12px;border-radius:20px;
                                    font-size:0.85em;">
                            🦎 {{ $ligne->reptile->nom ?? 'Reptile supprimé' }}
                            <span style="color:var(--brun);">×{{ $ligne->quantite }}</span>
                            <span style="color:var(--accent-orange);font-weight:600;">
                                {{ number_format($ligne->sous_total, 2, ',', ' ') }} €
                            </span>
                        </div>
                    @endforeach
                </div>
            @endif

        </div>
    @empty
        <div class="container">
            <p>Vous n'avez aucune commande pour le moment.</p>
            <a href="{{ route('reptiles.index') }}">
                <button class="connexion">Parcourir le catalogue</button>
            </a>
        </div>
    @endforelse

</div>

@endsection
