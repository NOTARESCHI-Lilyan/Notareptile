@extends('layouts.app')
@section('titre', 'Commande ' . $commande->reference . ' – Notareptile')

@section('contenu')

<button class="backButton" onclick="window.location.href='{{ route('commandes.index') }}'">← Mes commandes</button>

<h2>📦 Commande {{ $commande->reference }}</h2>

<div style="max-width:900px;margin:0 auto;padding:0 20px;display:grid;grid-template-columns:1.2fr 1fr;gap:30px;">

    {{-- Détail des articles --}}
    <div class="container" style="text-align:left;">
        <h3>🦎 Articles commandés</h3>

        @foreach($commande->lignes as $ligne)
            <div style="display:flex;gap:15px;padding:12px 0;border-bottom:1px solid var(--beige);align-items:center;">
                <img src="{{ $ligne->reptile ? $ligne->reptile->image_url : 'https://placehold.co/60x60/2d5016/fff?text=?' }}"
                     alt="{{ $ligne->reptile->nom ?? '?' }}"
                     style="width:60px;height:60px;object-fit:cover;border-radius:8px;">
                <div style="flex:1;">
                    <strong>{{ $ligne->reptile->nom ?? 'Reptile supprimé' }}</strong><br>
                    <span style="color:var(--brun);font-size:0.85em;">
                        {{ $ligne->reptile->categorie->nom ?? '' }}
                    </span>
                </div>
                <div style="text-align:right;">
                    <span style="color:var(--brun);">x{{ $ligne->quantite }}</span><br>
                    <span style="color:var(--accent-orange);font-weight:700;">
                        {{ number_format($ligne->sous_total, 2, ',', ' ') }} €
                    </span>
                </div>
            </div>
        @endforeach

        {{-- Totaux --}}
        <div style="margin-top:15px;display:flex;flex-direction:column;gap:6px;">
            <div style="display:flex;justify-content:space-between;">
                <span>Sous-total</span>
                <strong>{{ number_format($commande->sous_total, 2, ',', ' ') }} €</strong>
            </div>
            <div style="display:flex;justify-content:space-between;">
                <span>Frais de livraison</span>
                <strong>
                    {{ $commande->frais_livraison == 0 ? 'Gratuit 🎉' : number_format($commande->frais_livraison, 2, ',', ' ') . ' €' }}
                </strong>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:1.2em;font-weight:900;
                        color:var(--accent-orange);border-top:2px solid var(--accent-orange);
                        padding-top:8px;margin-top:5px;">
                <span>Total TTC</span>
                <span>{{ number_format($commande->total, 2, ',', ' ') }} €</span>
            </div>
        </div>
    </div>

    {{-- Infos commande --}}
    <div style="display:flex;flex-direction:column;gap:20px;">

        <div class="container" style="text-align:left;">
            <h3>📋 Statut</h3>
            <span style="background:{{ $commande->statut_color }};color:#fff;
                         padding:10px 24px;border-radius:25px;font-weight:700;font-size:1.1em;">
                {{ $commande->statut_label }}
            </span>
            <p style="margin-top:12px;color:var(--brun);font-size:0.9em;">
                Référence : <strong>{{ $commande->reference }}</strong><br>
                Passée le : <strong>{{ $commande->created_at->format('d/m/Y à H:i') }}</strong>
            </p>
        </div>

        <div class="container" style="text-align:left;">
            <h3>🏠 Livraison</h3>
            <p style="margin:0;line-height:1.7;">
                {{ $commande->adresse_livraison }}<br>
                {{ $commande->code_postal_livraison }} {{ $commande->ville_livraison }}
            </p>
            @if($commande->notes)
                <p style="margin-top:10px;color:var(--brun);font-size:0.9em;">
                    <em>{{ $commande->notes }}</em>
                </p>
            @endif
        </div>

    </div>

</div>

@endsection
