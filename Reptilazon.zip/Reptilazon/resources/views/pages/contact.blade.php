@extends('layouts.app')
@section('titre', 'Contact – ReptileShop')

@section('contenu')

<h2>📧 Nous Contacter</h2>

<div style="max-width:600px;margin:0 auto;padding:0 20px;">
    <form method="POST" action="{{ route('contact.envoyer') }}" class="inscriptionForm">
        @csrf
        <input type="text" name="nom" value="{{ old('nom') }}" required placeholder="Votre nom"
            style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
        <input type="email" name="email" value="{{ old('email') }}" required placeholder="Votre email"
            style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
        <input type="text" name="sujet" value="{{ old('sujet') }}" placeholder="Sujet"
            style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;">
        <textarea name="message" required placeholder="Votre message..." rows="6"
            style="padding:12px 15px;border:2px solid var(--beige);border-radius:8px;font-size:1em;resize:vertical;">{{ old('message') }}</textarea>
        <button type="submit" class="ajoutPanier" style="padding:14px;font-size:1.05em;">Envoyer le message</button>
    </form>

    <div class="container" style="margin-top:20px;">
        <h3>📞 Autres moyens de contact</h3>
        <p>📧 contact@reptileshop.fr</p>
        <p>📞 06 12 34 56 78 (Lun-Sam 9h-18h)</p>
        <p>📍 France métropolitaine</p>
    </div>
</div>

@endsection
