@extends('layouts.app')
@section('titre', 'À propos – ReptileShop')

@section('contenu')

<h2>🦎 À propos de ReptileShop</h2>

<div class="container" style="max-width:900px;">
    <p style="font-size:1.15em;line-height:1.9;">
        Bienvenue chez <strong>ReptileShop</strong>, votre spécialiste français de la vente de reptiles depuis 2015.
        Passionnés par ces animaux fascinants, nous mettons tout en œuvre pour vous proposer des animaux <strong>sains, bien élevés et socialisés</strong>.
    </p>

    <div class="grille_information" style="background:transparent;padding:0;margin-top:30px;">
        <div class="item_info" style="background:var(--beige);border:none;">
            <div class="icon_info">🏆</div>
            <h3 style="color:var(--vert-principal);">+10 ans d'expérience</h3>
            <p class="texte_info">Une décennie dédiée à l'élevage et la vente responsable de reptiles.</p>
        </div>
        <div class="item_info" style="background:var(--beige);border:none;">
            <div class="icon_info">🦎</div>
            <h3 style="color:var(--vert-principal);">+50 espèces</h3>
            <p class="texte_info">Un large choix de serpents, geckos, lézards, tortues et caméléons.</p>
        </div>
        <div class="item_info" style="background:var(--beige);border:none;">
            <div class="icon_info">😊</div>
            <h3 style="color:var(--vert-principal);">+2000 clients</h3>
            <p class="texte_info">Des milliers de passionnés nous font confiance chaque année.</p>
        </div>
    </div>
</div>

<div class="cta-section" style="max-width:800px;">
    <h2 class="cta-title">Vous avez des questions ?</h2>
    <p class="cta-text">Notre équipe de passionnés est là pour vous conseiller.</p>
    <div class="cta-buttons">
        <a href="{{ route('contact') }}"><button class="ajoutPanier" style="width:auto;padding:15px 30px;">Nous contacter</button></a>
    </div>
</div>

@endsection
