@extends('layouts.app')
@section('titre', 'ReptileShop – Accueil')

@section('contenu')

{{-- Catégories --}}
<h2>Nos Catégories</h2>
<div class="reptilesButton">
   @foreach($categories as $cat)
    <a href="{{ route('reptiles.categorie', $cat->type_reptile) }}">
        <div class="carte_categ">
            <div class="contenu_categ">
                <div class="icon_categ" style="font-size:4em;">{{ $cat->icone }}</div>
                <h3 style="color:#fff;font-size:1.5em;margin:10px 0 5px;">{{ $cat->nom_commun }}</h3>
                <p style="color:rgba(255,255,255,0.8);margin:0;">{{ $cat->reptiles_count }} reptile(s)</p>
            </div>
        </div>
        <span class="reptile-label">{{ $cat->nom_commun }}</span>
    </a>
    @endforeach
</div>

{{-- Reptiles en vedette --}}
@if($reptilesVedette->count())
<h2>⭐ Coups de cœur</h2>
<div class="grille_produit">
    @foreach($reptilesVedette as $reptile)
        @include('reptiles._carte', ['reptile' => $reptile])
    @endforeach
</div>
@endif

{{-- Section infos --}}
<div class="section_information">
    <h2 class="section_titre">Pourquoi choisir ReptileShop ?</h2>
    <p class="soustitre_info">Votre confiance, notre priorité</p>
    <div class="grille_information">
        <div class="item_info">
            <div class="icon_info">🏥</div>
            <h3 style="color:#fff;">Animaux certifiés</h3>
            <p class="texte_info" style="color:rgba(255,255,255,0.85);">Tous nos reptiles sont contrôlés vétérinairement et livrés avec certificat CITES si requis.</p>
        </div>
        <div class="item_info">
            <div class="icon_info">🚚</div>
            <h3 style="color:#fff;">Livraison sécurisée</h3>
            <p class="texte_info" style="color:rgba(255,255,255,0.85);">Transport spécialisé avec maintien de la température. Livraison gratuite dès 150€.</p>
        </div>
        <div class="item_info">
            <div class="icon_info">💬</div>
            <h3 style="color:#fff;">Conseil d'experts</h3>
            <p class="texte_info" style="color:rgba(255,255,255,0.85);">Notre équipe est disponible 7j/7 pour vous accompagner dans votre élevage.</p>
        </div>
        <div class="item_info">
            <div class="icon_info">🛡️</div>
            <h3 style="color:#fff;">Garantie vivant</h3>
            <p class="texte_info" style="color:rgba(255,255,255,0.85);">Chaque animal est garanti à la réception. Satisfait ou remboursé sous 48h.</p>
        </div>
    </div>
</div>

{{-- CTA --}}
<div class="cta-section">
    <h2 class="cta-title">🦎 Des centaines de reptiles disponibles</h2>
    <p class="cta-text">Serpents, geckos, caméléons, tortues... Trouvez votre compagnon idéal !</p>
    <div class="cta-buttons">
        <a href="{{ route('reptiles.index') }}">
            <button class="ajoutPanier" style="width:auto;padding:15px 35px;">Voir le catalogue</button>
        </a>
        <a href="{{ route('contact') }}">
            <button class="connexion">Nous contacter</button>
        </a>
    </div>
</div>

{{-- Derniers arrivages --}}
@if($derniers->count())
<h2>🆕 Derniers arrivages</h2>
<div class="grille_produit">
    @foreach($derniers as $reptile)
        @include('reptiles._carte', ['reptile' => $reptile])
    @endforeach
</div>
@endif

@endsection
