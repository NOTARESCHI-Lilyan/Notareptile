@extends('layouts.app')
@section('titre', 'Mon Panier – ReptileShop')

@section('contenu')

<div class="panier-page">
    <h2 class="Titre">🛒 Mon Panier</h2>

    @if(empty($panier))
        <div class="panier-vide">
            <div class="panier-vide-icon">🛒</div>
            <h3>Votre panier est vide</h3>
            <p>Découvrez notre catalogue et ajoutez des reptiles à votre panier !</p>
            <a href="{{ route('reptiles.index') }}" class="panier-continuer">Voir le catalogue</a>
        </div>
    @else
        {{-- Articles --}}
        @foreach($panier as $id => $item)
            <div class="panier-item">
                <div class="button-panier">
                    <form method="POST" action="{{ route('panier.supprimer', $id) }}">
                        @csrf @method('DELETE')
                        <button type="submit" class="delete-btn" title="Supprimer">🗑</button>
                    </form>
                </div>

                <div class="panier-image">
                    <img src="{{ $item['image'] }}" alt="{{ $item['nom'] }}">
                </div>

                <div class="description">
                    <span>{{ $item['nom'] }}</span>
                    <span style="color:var(--brun);font-size:0.9em;">{{ $item['categorie'] }}</span>
                    <span class="price">{{ number_format($item['prix'], 2, ',', ' ') }} €</span>

                    <form method="POST" action="{{ route('panier.modifier', $id) }}" class="quantity">
                        @csrf @method('PATCH')
                        <label>Quantité :</label>
                        <input type="number" name="quantite" value="{{ $item['quantite'] }}" min="1">
                        <button type="submit" class="connexion" style="padding:8px 18px;font-size:0.9em;">Mettre à jour</button>
                    </form>
                </div>

                <div style="font-size:1.5em;font-weight:900;color:var(--accent-orange);">
                    {{ number_format($item['prix'] * $item['quantite'], 2, ',', ' ') }} €
                </div>
            </div>
        @endforeach

        {{-- Résumé --}}
        <div class="panier-total">
            <h3>Récapitulatif</h3>
            <div class="total-row">
                <span>Sous-total</span>
                <span>{{ number_format($total, 2, ',', ' ') }} €</span>
            </div>
            <div class="total-row">
                <span>Livraison</span>
                <span>{{ $total >= 150 ? 'Gratuite 🎉' : '9,90 €' }}</span>
            </div>
            @if($total < 150)
                <div class="total-row" style="font-size:0.9em;color:var(--brun);border:none;padding-top:5px;">
                    <span>Plus que {{ number_format(150 - $total, 2, ',', ' ') }} € pour la livraison gratuite !</span>
                </div>
            @endif
            <div class="total-row">
                <span>Total</span>
                <span>{{ number_format($total + ($total >= 150 ? 0 : 9.90), 2, ',', ' ') }} €</span>
            </div>

            <div style="display:flex;gap:15px;margin-top:20px;flex-wrap:wrap;">
                <form method="POST" action="{{ route('panier.vider') }}" style="flex:1;">
                    @csrf @method('DELETE')
                    <button type="submit" class="buttonRetour" style="position:relative;top:0;left:0;width:100%;" onclick="return confirm('Vider le panier ?')">
                        🗑 Vider le panier
                    </button>
                </form>
                @auth
                    <a href="{{ route('commander') }}" style="flex:2;text-decoration:none;">
                        <button class="panier-commande">✅ Passer la commande</button>
                    </a>
                @else
                    <a href="{{ route('login') }}" style="flex:2;text-decoration:none;">
                        <button class="panier-commande">🔐 Se connecter pour commander</button>
                    </a>
                @endauth
            </div>
        </div>
    @endif
</div>

@endsection
