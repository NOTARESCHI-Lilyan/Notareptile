<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('titre', 'ReptileShop – Vente de reptiles en ligne')</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>

{{-- HEADER --}}
<div class="header">
    {{-- Bouton panier --}}
    <div class="contenu_panier">
        <a href="{{ route('panier.index') }}" style="text-decoration:none;">
            <div class="panier">
                🛒
                @php $nbPanier = array_sum(array_column(session('panier', []), 'quantite')); @endphp
                @if($nbPanier > 0)
                    <span class="panier-badge">{{ $nbPanier }}</span>
                @endif
            </div>
        </a>
    </div>

    <div class="class_header">
        <a href="{{ route('accueil') }}" style="text-decoration:none;">
            <h1>🦎 ReptileShop</h1>
        </a>
        <p class="header_soustitre">Spécialiste de la vente de reptiles</p>
        <p class="header_slogan">« Des reptiles sains, élevés avec passion »</p>

        {{-- Bouton connexion/compte --}}
        <div class="connectionButton">
            @auth
                <a href="{{ route('compte') }}">
                    <button class="connexion">👤 Mon compte – {{ Auth::user()->prenom }}</button>
                </a>
                <form method="POST" action="{{ route('logout') }}" style="display:inline;">
                    @csrf
                    <button type="submit" class="connexion" style="background: linear-gradient(135deg,#7a5c3a,#5a3d1e); margin-left:10px;">Déconnexion</button>
                </form>
            @else
                <a href="{{ route('login') }}">
                    <button class="connexion">🔐 Se connecter</button>
                </a>
                <a href="{{ route('register') }}" style="margin-left:10px;">
                    <button class="connexion" style="background: linear-gradient(135deg,var(--vert-secondaire),var(--vert-principal));">Créer un compte</button>
                </a>
            @endauth
        </div>
    </div>
</div>

{{-- NAVIGATION --}}
<div style="max-width:1200px;margin:20px auto;padding:0 20px;">
    <ul class="nav">
        <li><a href="{{ route('accueil') }}">🏠 Accueil</a></li>
        <li class="dropdown">
            <a href="{{ route('reptiles.index') }}">🦎 Nos Reptiles ▾</a>
            <ul class="submenu">
                <li class="submenu-title">Catégories</li>
                @foreach(\App\Models\Espece::select('type_reptile','icone','nom_commun')->distinct()->get() as $cat)
                    <li><a href="{{ route('reptiles.categorie', $cat->type_reptile) }}">{{ $cat->icone }} {{ $cat->nom_commun }}</a></li>
                @endforeach
                <li class="submenu-title">Filtres</li>
                <li><a href="{{ route('reptiles.index', ['sexe' => 'mâle']) }}">♂ Mâles</a></li>
                <li><a href="{{ route('reptiles.index', ['sexe' => 'femelle']) }}">♀ Femelles</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="{{ route('articles.index', 'nourriture') }}">🛍️ Boutique ▾</a>
            <ul class="submenu">
                <li class="submenu-title">Catégories</li>
                <li><a href="{{ route('articles.index', 'nourriture') }}">🍖 Nourriture</a></li>
                <li><a href="{{ route('articles.index', 'substrat') }}">🪨 Substrat</a></li>
                <li><a href="{{ route('articles.index', 'terrarium') }}">🏠 Terrarium & Équipements</a></li>
            </ul>
        </li>
        <li><a href="{{ route('panier.index') }}">🛒 Panier</a></li>
        <li><a href="{{ route('apropos') }}">ℹ️ À propos</a></li>
        <li><a href="{{ route('contact') }}">📧 Contact</a></li>
        @auth
            @if(Auth::user()->is_admin)
                <li><a href="{{ route('admin.dashboard') }}" style="color:var(--accent-orange);">⚙️ Admin</a></li>
            @endif
        @endauth
    </ul>
</div>

{{-- FLASH MESSAGES --}}
@if(session('success'))
    <div style="background:linear-gradient(135deg,var(--vert-secondaire),var(--vert-principal));color:#fff;text-align:center;padding:15px 20px;margin:0 auto 10px;max-width:1200px;border-radius:10px;">
        ✅ {{ session('success') }}
    </div>
@endif
@if(session('error'))
    <div style="background:linear-gradient(135deg,#ff4757,#c0392b);color:#fff;text-align:center;padding:15px 20px;margin:0 auto 10px;max-width:1200px;border-radius:10px;">
        ❌ {{ session('error') }}
    </div>
@endif
@if($errors->any())
    <div style="background:#fff3cd;color:#856404;text-align:center;padding:15px 20px;margin:0 auto 10px;max-width:1200px;border-radius:10px;">
        @foreach($errors->all() as $err) ⚠️ {{ $err }}<br> @endforeach
    </div>
@endif

{{-- CONTENU --}}
@yield('contenu')

{{-- FOOTER --}}
<footer style="background:linear-gradient(135deg,var(--vert-principal),var(--vert-secondaire));color:#fff;padding:50px 20px;margin-top:60px;text-align:center;">
    <div style="max-width:1200px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:30px;">
        <div>
            <h3 style="color:var(--accent);margin-bottom:15px;">🦎 ReptileShop</h3>
            <p style="color:rgba(255,255,255,0.8);font-size:0.95em;">Votre spécialiste en reptiles depuis 2015. Animaux sains, élevés avec passion.</p>
        </div>
        <div>
            <h3 style="color:var(--accent);margin-bottom:15px;">Navigation</h3>
            <ul style="list-style:none;padding:0;">
                <li><a href="{{ route('reptiles.index') }}" style="color:rgba(255,255,255,0.8);text-decoration:none;">Catalogue</a></li>
                <li><a href="{{ route('apropos') }}" style="color:rgba(255,255,255,0.8);text-decoration:none;">À propos</a></li>
                <li><a href="{{ route('contact') }}" style="color:rgba(255,255,255,0.8);text-decoration:none;">Contact</a></li>
            </ul>
        </div>
        <div>
            <h3 style="color:var(--accent);margin-bottom:15px;">Contact</h3>
            <p style="color:rgba(255,255,255,0.8);font-size:0.95em;">📧 contact@reptileshop.fr<br>📞 06 12 34 56 78<br>📍 France</p>
        </div>
        <div>
            <h3 style="color:var(--accent);margin-bottom:15px;">Infos</h3>
            <p style="color:rgba(255,255,255,0.8);font-size:0.95em;">🚚 Livraison sécurisée<br>✅ Animaux certifiés CITES<br>💬 Support 7j/7</p>
        </div>
    </div>
    <p style="margin-top:30px;color:rgba(255,255,255,0.5);font-size:0.85em;">© {{ date('Y') }} ReptileShop – Tous droits réservés</p>
</footer>

</body>
</html>
