<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('reptiles', function (Blueprint $table) {
            $table->id();
            $table->string('couleur')->nullable();
            $table->string('morph')->nullable();
            $table->unsignedInteger('age_mois')->nullable();
            $table->enum('sexe', ['mâle', 'femelle', 'inconnu'])->default('inconnu');
            $table->foreignId('espece_id')->constrained('especes')->cascadeOnDelete();
            $table->foreignId('eleveur_id')->constrained('eleveurs')->cascadeOnDelete();
            $table->foreignId('produit_id')->unique()->constrained('produits')->cascadeOnDelete();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('reptiles'); }
};
