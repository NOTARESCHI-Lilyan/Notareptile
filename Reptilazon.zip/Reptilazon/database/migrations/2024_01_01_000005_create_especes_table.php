<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('especes', function (Blueprint $table) {
            $table->id();
            $table->string('type_reptile');       // Serpent, Gecko, Lézard...
            $table->string('nom_commun');          // Ball Python, Gecko Léopard...
            $table->string('nom_scientifique')->nullable();
            $table->string('lien_video')->nullable();
            $table->string('icone')->nullable();
            $table->text('description')->nullable();
            $table->text('conseils_elevage')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('especes'); }
};
