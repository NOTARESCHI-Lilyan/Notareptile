<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('produits', function (Blueprint $table) {
            $table->id();
            $table->decimal('prix_unitaire', 10, 2);
            $table->unsignedInteger('stock')->default(0);
            $table->boolean('actif')->default(true);
            $table->boolean('en_vedette')->default(false);
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('produits'); }
};
