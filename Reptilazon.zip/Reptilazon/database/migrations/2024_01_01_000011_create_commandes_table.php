<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('commandes', function (Blueprint $table) {
            $table->id();
            $table->string('reference')->unique();
            $table->boolean('est_valide')->default(false);
            $table->decimal('total', 10, 2)->default(0);
            $table->decimal('frais_livraison', 10, 2)->default(0);
            $table->enum('statut', ['en_attente','confirmee','expediee','livree','annulee'])->default('en_attente');
            $table->string('adresse_livraison')->nullable();
            $table->string('ville_livraison')->nullable();
            $table->string('code_postal_livraison')->nullable();
            $table->text('notes')->nullable();
            $table->foreignId('utilisateur_id')->constrained('utilisateurs')->cascadeOnDelete();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('commandes'); }
};
