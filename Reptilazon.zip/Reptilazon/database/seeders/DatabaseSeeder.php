<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\Utilisateur;
use App\Models\Eleveur;
use App\Models\Fournisseur;
use App\Models\TypeArticle;
use App\Models\Espece;
use App\Models\Produit;
use App\Models\Reptile;
use App\Models\Article;
use App\Models\Approvisionnement;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // ─── Utilisateurs ──────────────────────────────────────────────
        Utilisateur::create([
            'nom' => 'Admin', 'prenom' => 'Super',
            'email' => 'admin@reptilazon.fr',
            'password' => Hash::make('password'),
            'is_admin' => true,
        ]);
        Utilisateur::create([
            'nom' => 'Dupont', 'prenom' => 'Jean',
            'email' => 'jean@example.fr',
            'telephone' => '06 12 34 56 78',
            'adresse' => '12 rue des Lézards',
            'password' => Hash::make('password'),
        ]);

        // ─── Éleveurs ──────────────────────────────────────────────────
        $eleveur1 = Eleveur::create(['nom' => 'Martin', 'prenom' => 'Pierre', 'adresse' => 'Lyon', 'telephone' => '06 11 22 33 44']);
        $eleveur2 = Eleveur::create(['nom' => 'Durand', 'prenom' => 'Sophie', 'adresse' => 'Bordeaux', 'telephone' => '07 55 66 77 88']);

        // ─── Fournisseurs ──────────────────────────────────────────────
        $fourn1 = Fournisseur::create(['nom' => 'ReptileSupply Pro']);
        $fourn2 = Fournisseur::create(['nom' => 'ExoTerrariums France']);

        // ─── Types d'articles ──────────────────────────────────────────
        $typeTerr  = TypeArticle::create(['libelle' => 'Terrarium',  'icone' => '🏠']);
        $typeNourr = TypeArticle::create(['libelle' => 'Nourriture', 'icone' => '🦗']);
        $typeSubst = TypeArticle::create(['libelle' => 'Substrat',   'icone' => '🌿']);
        $typeChauf = TypeArticle::create(['libelle' => 'Chauffage',  'icone' => '🌡️']);

        // ─── Espèces ───────────────────────────────────────────────────
        $especes = [
            ['type_reptile' => 'Serpent',   'nom_commun' => 'Ball Python',       'nom_scientifique' => 'Python regius',          'icone' => '🐍', 'description' => 'Le serpent idéal pour débutants.', 'conseils_elevage' => "T° : 28-32°C chaud / 24-26°C froid.\nHumidité : 60-80%.\nNourriture : souris décongelées toutes 1-2 semaines."],
            ['type_reptile' => 'Serpent',   'nom_commun' => 'Boa Constrictor',   'nom_scientifique' => 'Boa constrictor',         'icone' => '🐍', 'description' => 'Grand serpent docile apprécié des amateurs.'],
            ['type_reptile' => 'Serpent',   'nom_commun' => 'Couleuvre Ratière', 'nom_scientifique' => 'Pantherophis obsoletus',  'icone' => '🐍', 'description' => 'Très active et facile à nourrir.'],
            ['type_reptile' => 'Gecko',     'nom_commun' => 'Gecko Léopard',     'nom_scientifique' => 'Eublepharis macularius',  'icone' => '🦎', 'description' => 'Un des lézards les plus populaires.', 'conseils_elevage' => "T° : 28-32°C côté chaud.\nNourriture : grillons et vers de farine."],
            ['type_reptile' => 'Gecko',     'nom_commun' => 'Gecko Crêté',       'nom_scientifique' => 'Correlophus ciliatus',    'icone' => '🦎', 'description' => 'Peut se nourrir de purée de fruits.'],
            ['type_reptile' => 'Lézard',    'nom_commun' => 'Dragon Barbu',      'nom_scientifique' => 'Pogona vitticeps',        'icone' => '🦕', 'description' => 'Lézard sociable qui reconnaît son propriétaire.', 'conseils_elevage' => "UV nécessaires.\nT° : 35-42°C côté chaud.\nNourriture mixte : insectes et végétaux."],
            ['type_reptile' => 'Tortue',    'nom_commun' => 'Tortue Grecque',    'nom_scientifique' => 'Testudo graeca',          'icone' => '🐢', 'description' => 'Tortue terrestre robuste et longévive.'],
            ['type_reptile' => 'Caméléon',  'nom_commun' => 'Caméléon Voilé',   'nom_scientifique' => 'Chamaeleo calyptratus',   'icone' => '🐊', 'description' => 'Recommandé pour débuter avec les caméléons.'],
            ['type_reptile' => 'Caméléon',  'nom_commun' => 'Caméléon Panthère','nom_scientifique' => 'Furcifer pardalis',       'icone' => '🐊', 'description' => 'Un des plus beaux caméléons au monde.'],
        ];

        $especeModels = [];
        foreach ($especes as $e) {
            $especeModels[] = Espece::create($e);
        }

        // ─── Reptiles ──────────────────────────────────────────────────
        $reptilesData = [
            ['espece' => 0, 'eleveur' => $eleveur1, 'couleur' => 'Normal',   'age_mois' => 8,  'sexe' => 'mâle',    'prix' => 89,  'stock' => 5, 'vedette' => true],
            ['espece' => 0, 'eleveur' => $eleveur1, 'couleur' => 'Albino',   'age_mois' => 6,  'sexe' => 'femelle', 'prix' => 250, 'stock' => 2, 'vedette' => true,  'morph' => 'Albino'],
            ['espece' => 1, 'eleveur' => $eleveur2, 'couleur' => 'Normal',   'age_mois' => 18, 'sexe' => 'mâle',    'prix' => 180, 'stock' => 3, 'vedette' => true],
            ['espece' => 2, 'eleveur' => $eleveur1, 'couleur' => 'Normal',   'age_mois' => 4,  'sexe' => 'inconnu', 'prix' => 45,  'stock' => 8],
            ['espece' => 3, 'eleveur' => $eleveur2, 'couleur' => 'Normal',   'age_mois' => 5,  'sexe' => 'femelle', 'prix' => 55,  'stock' => 10,'vedette' => true],
            ['espece' => 3, 'eleveur' => $eleveur1, 'couleur' => 'Tangerine','age_mois' => 7,  'sexe' => 'mâle',    'prix' => 120, 'stock' => 4,  'morph' => 'Tangerine'],
            ['espece' => 4, 'eleveur' => $eleveur2, 'couleur' => 'Normal',   'age_mois' => 3,  'sexe' => 'inconnu', 'prix' => 70,  'stock' => 6],
            ['espece' => 5, 'eleveur' => $eleveur1, 'couleur' => 'Normal',   'age_mois' => 9,  'sexe' => 'mâle',    'prix' => 110, 'stock' => 4, 'vedette' => true],
            ['espece' => 6, 'eleveur' => $eleveur2, 'couleur' => 'Normal',   'age_mois' => 36, 'sexe' => 'inconnu', 'prix' => 95,  'stock' => 6],
            ['espece' => 7, 'eleveur' => $eleveur1, 'couleur' => 'Normal',   'age_mois' => 6,  'sexe' => 'mâle',    'prix' => 150, 'stock' => 3],
            ['espece' => 8, 'eleveur' => $eleveur2, 'couleur' => 'Ambilobe', 'age_mois' => 8,  'sexe' => 'mâle',    'prix' => 350, 'stock' => 2, 'vedette' => true, 'morph' => 'Ambilobe'],
        ];

        foreach ($reptilesData as $r) {
            $produit = Produit::create([
                'prix_unitaire' => $r['prix'],
                'stock'         => $r['stock'],
                'en_vedette'    => $r['vedette'] ?? false,
                'actif'         => true,
            ]);
            Reptile::create([
                'espece_id'  => $especeModels[$r['espece']]->id,
                'eleveur_id' => $r['eleveur']->id,
                'couleur'    => $r['couleur'],
                'morph'      => $r['morph'] ?? null,
                'age_mois'   => $r['age_mois'],
                'sexe'       => $r['sexe'],
                'produit_id' => $produit->id,
            ]);
        }

        // ─── Articles ──────────────────────────────────────────────────
        $articlesData = [
            ['nom' => 'Terrarium Starter 60x40x40', 'type' => $typeTerr,  'prix' => 89,  'stock' => 15, 'desc' => 'Terrarium verre avec ventilation latérale, idéal pour gecko léopard ou serpent juvénile.'],
            ['nom' => 'Terrarium Pro 120x60x60',    'type' => $typeTerr,  'prix' => 199, 'stock' => 8,  'desc' => 'Grand terrarium pour adulte. Portes coulissantes, fond étanche.', 'vedette' => true],
            ['nom' => 'Kit Chauffage Complet',       'type' => $typeChauf, 'prix' => 45,  'stock' => 20, 'desc' => 'Tapis chauffant + thermostat + thermomètre digital.'],
            ['nom' => 'Lampe UV-B 10% Repti',        'type' => $typeChauf, 'prix' => 29,  'stock' => 25, 'desc' => 'Lampe UV-B nécessaire pour les dragons barbus et tortues.'],
            ['nom' => 'Grillons Vivants (100)',       'type' => $typeNourr, 'prix' => 4,   'stock' => 50, 'desc' => 'Grillons domestiques, taille L, idéals pour la plupart des lézards.'],
            ['nom' => 'Souris Congelées (10)',        'type' => $typeNourr, 'prix' => 12,  'stock' => 30, 'desc' => 'Souris adultes congelées pour serpents. Conditionnées individuellement.'],
            ['nom' => 'Blattes de Madagascar (50)',   'type' => $typeNourr, 'prix' => 8,   'stock' => 40, 'desc' => 'Proies riches en protéines, peu odorantes.', 'vedette' => true],
            ['nom' => 'Substrat Coco Fibre 5L',      'type' => $typeSubst, 'prix' => 9,   'stock' => 35, 'desc' => 'Substrat naturel à base de fibre de coco, retient bien l\'humidité.'],
            ['nom' => 'Terreau Reptile 10L',          'type' => $typeSubst, 'prix' => 14,  'stock' => 20, 'desc' => 'Mélange terreau + sable pour les espèces qui fouissent.'],
            ['nom' => 'Sable de Désert 5kg',          'type' => $typeSubst, 'prix' => 11,  'stock' => 25, 'desc' => 'Sable fin pour tortues et agames des déserts.'],
        ];

        foreach ($articlesData as $a) {
            $produit = Produit::create([
                'prix_unitaire' => $a['prix'],
                'stock'         => $a['stock'],
                'en_vedette'    => $a['vedette'] ?? false,
                'actif'         => true,
            ]);
            $article = Article::create([
                'nom'             => $a['nom'],
                'description'     => $a['desc'],
                'type_article_id' => $a['type']->id,
                'produit_id'      => $produit->id,
            ]);
        }

        // ─── Approvisionnements ────────────────────────────────────────
        $articles = Article::all();
        Approvisionnement::create(['article_id' => $articles[0]->id, 'fournisseur_id' => $fourn2->id, 'quantite' => 10, 'date_appro' => '2026-05-01']);
        Approvisionnement::create(['article_id' => $articles[1]->id, 'fournisseur_id' => $fourn2->id, 'quantite' => 5,  'date_appro' => '2026-05-15']);
        Approvisionnement::create(['article_id' => $articles[4]->id, 'fournisseur_id' => $fourn1->id, 'quantite' => 100,'date_appro' => '2026-06-01']);
        Approvisionnement::create(['article_id' => $articles[7]->id, 'fournisseur_id' => $fourn1->id, 'quantite' => 50, 'date_appro' => '2026-06-01']);
    }
}
