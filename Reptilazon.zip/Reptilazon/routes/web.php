<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AccueilController;
use App\Http\Controllers\ReptileController;
use App\Http\Controllers\PanierController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CommandeController;
use App\Http\Controllers\ArticleController;

// ─── Pages publiques ───────────────────────────────────────────────────────────
Route::get('/',         [AccueilController::class, 'index'])->name('accueil');
Route::get('/a-propos', [AccueilController::class, 'apropos'])->name('apropos');
Route::get('/contact',  [AccueilController::class, 'contact'])->name('contact');
Route::post('/contact', [AccueilController::class, 'contactEnvoyer'])->name('contact.envoyer');

// ─── Catalogue reptiles ────────────────────────────────────────────────────────
Route::get('/reptiles',                      [ReptileController::class, 'index'])->name('reptiles.index');
Route::get('/reptiles/categorie/{type}',     [ReptileController::class, 'categorie'])->name('reptiles.categorie');
Route::get('/reptiles/{id}',                 [ReptileController::class, 'show'])->name('reptiles.show');

// ─── Catalogue articles (nourriture / substrat / terrarium) ───────────────────
Route::get('/boutique/{categorie}',          [ArticleController::class, 'index'])->name('articles.index');
Route::get('/boutique/produit/{id}',         [ArticleController::class, 'show'])->name('articles.show');

// ─── Panier (session, pas de table dédiée) ─────────────────────────────────────
Route::get   ('/panier',                  [PanierController::class, 'index'])->name('panier.index');
Route::post  ('/panier/ajouter/{id}',     [PanierController::class, 'ajouter'])->name('panier.ajouter');
Route::patch ('/panier/modifier/{id}',    [PanierController::class, 'modifier'])->name('panier.modifier');
Route::delete('/panier/supprimer/{id}',   [PanierController::class, 'supprimer'])->name('panier.supprimer');
Route::delete('/panier/vider',            [PanierController::class, 'vider'])->name('panier.vider');

// ─── Auth ──────────────────────────────────────────────────────────────────────
Route::get ('/connexion',   [AuthController::class, 'loginForm'])->name('login');
Route::post('/connexion',   [AuthController::class, 'login'])->name('login.post');
Route::get ('/inscription', [AuthController::class, 'registerForm'])->name('register');
Route::post('/inscription', [AuthController::class, 'register'])->name('register.post');
Route::post('/deconnexion', [AuthController::class, 'logout'])->name('logout');

// ─── Espace client (connecté) ──────────────────────────────────────────────────
Route::middleware('auth')->group(function () {
    Route::get('/mon-compte', [AuthController::class, 'compte'])->name('compte');

    // Commandes : lit/écrit dans `commandes` et `commande_lignes`
    Route::get ('/mes-commandes',       [CommandeController::class, 'index'])->name('commandes.index');
    Route::get ('/mes-commandes/{id}',  [CommandeController::class, 'show'])->name('commandes.show');
    Route::get ('/commander',           [CommandeController::class, 'checkout'])->name('commander');
    Route::post('/commander',           [CommandeController::class, 'confirmer'])->name('commander.confirmer');
});

// ─── Admin ─────────────────────────────────────────────────────────────────────
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminController::class, 'dashboard'])->name('dashboard');

    // CRUD reptiles (resource → index, create, store, edit, update, destroy)
    Route::resource('reptiles', AdminController::class);

    // Gestion commandes admin : lit `commandes` avec jointure `users`
    Route::get   ('/commandes',              [AdminController::class, 'commandes'])->name('commandes');
    Route::patch ('/commandes/{id}/statut',  [AdminController::class, 'updateStatut'])->name('commandes.statut');
});
